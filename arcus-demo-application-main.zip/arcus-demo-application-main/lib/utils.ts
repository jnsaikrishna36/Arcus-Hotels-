import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { differenceInDays, format, parseISO } from 'date-fns';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number, currency = 'USD') {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount);
}

export function formatDate(dateStr: string, fmt = 'dd MMM yyyy') {
  try { return format(parseISO(dateStr), fmt); } catch { return dateStr; }
}

export function calcNights(checkIn: string, checkOut: string) {
  try { return differenceInDays(parseISO(checkOut), parseISO(checkIn)); } catch { return 0; }
}

export function formatCardNumber(value: string) {
  return value.replace(/\D/g, '').slice(0, 16).replace(/(\d{4})/g, '$1 ').trim();
}

export function maskCardNumber(cardNumber: string) {
  const clean = cardNumber.replace(/\s/g, '');
  return `•••• •••• •••• ${clean.slice(-4)}`;
}

export function getInitials(firstName: string, lastName: string) {
  return `${firstName[0] || ''}${lastName[0] || ''}`.toUpperCase();
}

export function generateColor(str: string) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash);
  const hue = hash % 360;
  return `hsl(${hue}, 65%, 50%)`;
}
