import { User } from '@/types';
import { seedUsers } from '@/mocks/data/users';

type UserWithPassword = User & { password: string };

// Module-level singleton — persists for the lifetime of the Node.js server process
const users: UserWithPassword[] = [...seedUsers];

export function findByEmail(email: string) {
  return users.find(u => u.email.toLowerCase() === email.toLowerCase());
}

export function findById(id: string) {
  return users.find(u => u.id === id);
}

export function addUser(user: UserWithPassword) {
  users.push(user);
}

export function updateUser(id: string, updates: Partial<UserWithPassword>) {
  const idx = users.findIndex(u => u.id === id);
  if (idx !== -1) users[idx] = { ...users[idx], ...updates };
}

export function generateToken(userId: string): string {
  const payload = JSON.stringify({ userId, exp: Date.now() + 86400000, iat: Date.now() });
  return Buffer.from(payload).toString('base64');
}

export function parseToken(token: string): { userId: string } | null {
  try {
    return JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
  } catch {
    return null;
  }
}
