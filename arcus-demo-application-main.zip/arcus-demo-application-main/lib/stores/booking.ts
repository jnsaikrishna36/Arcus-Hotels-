import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { BookingDraft } from '@/types';

interface BookingStore {
  draft: BookingDraft | null;
  setDraft: (draft: BookingDraft) => void;
  clearDraft: () => void;
}

export const useBookingStore = create<BookingStore>()(
  persist(
    (set) => ({
      draft: null,
      setDraft: (draft) => set({ draft }),
      clearDraft: () => set({ draft: null }),
    }),
    { name: 'arcus-booking-draft' }
  )
);
