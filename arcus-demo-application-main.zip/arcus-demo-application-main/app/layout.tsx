'use client';
import './globals.css';
import { useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/Toaster';
import { Bricolage_Grotesque, Inter } from 'next/font/google';

const bricolage = Bricolage_Grotesque({
  subsets: ['latin'],
  weight: ['500', '600', '700', '800'],
  variable: '--font-bricolage',
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-inter',
  display: 'swap',
});

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30000 } },
});

async function initMocks() {
  if (typeof window === 'undefined') return;
  const { worker } = await import('../mocks/browser');
  return worker.start({ onUnhandledRequest: 'bypass' });
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    initMocks().then(() => setReady(true));
  }, []);
  return (
    <html lang="en" className={`${bricolage.variable} ${inter.variable}`}>
      <head>
        <title>Arcus Go</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body>
        <QueryClientProvider client={queryClient}>
          {ready ? children : (
            <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100vh' }}>
              <div style={{ textAlign:'center' }}>
                <div style={{ fontFamily:"'Bricolage Grotesque','Inter',sans-serif", fontSize:'28px', color:'var(--accent)', marginBottom:'8px', fontWeight: 800, letterSpacing: '-0.03em' }}>Arcus Go</div>
                <div style={{ color:'var(--text-muted)', fontSize:'14px' }}>Loading…</div>
              </div>
            </div>
          )}
          <Toaster />
        </QueryClientProvider>
      </body>
    </html>
  );
}
