'use client';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useBookingStore } from '@/lib/stores/booking';
import { Navbar } from '@/components/layout/Navbar';
import { api } from '@/lib/api';
import { formatCurrency, formatCardNumber } from '@/lib/utils';
import { toast } from '@/components/ui/Toaster';
import { CreditCard, Lock, ArrowLeft, Check, AlertCircle } from 'lucide-react';

type PaymentMethod = 'card' | 'paypal';

function PayPalMark({ size = 18 }: { size?: number }) {
  return (
    <span style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontWeight: 800, fontSize: size, letterSpacing: '-0.03em', lineHeight: 1 }}>
      <span style={{ color: '#003087' }}>Pay</span><span style={{ color: '#009cde' }}>Pal</span>
    </span>
  );
}

export default function PaymentPage() {
  const router = useRouter();
  const { draft, clearDraft } = useBookingStore();
  const [method, setMethod] = useState<PaymentMethod>('card');
  const [card, setCard] = useState({ holder: '', number: '', expiry: '', cvv: '' });
  const [billing, setBilling] = useState({ street: '', city: '', state: '', zip: '', country: 'United States' });
  const [paypal, setPaypal] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [saveCard, setSaveCard] = useState(false);
  const paidRef = useRef(false);

  useEffect(() => {
    if (!draft && !paidRef.current) router.push('/hotels/search');
  }, [draft, router]);

  if (!draft) return null;

  const taxes = Math.round(draft.totalPrice * 0.12);
  const grandTotal = draft.totalPrice + taxes + 25;

  const validate = () => {
    const e: Record<string, string> = {};
    if (method === 'card') {
      if (!card.holder.trim()) e.holder = 'Card holder name required';
      if (!card.number || card.number.replace(/\s/g,'').length < 16) e.number = 'Enter a valid 16-digit card number';
      if (!card.expiry || !/^\d{2}\/\d{2}$/.test(card.expiry)) e.expiry = 'Use MM/YY format';
      if (!card.cvv || card.cvv.length < 3) e.cvv = 'Enter 3 or 4 digit CVV';
      if (!billing.street.trim()) e.street = 'Street address required';
      if (!billing.city.trim()) e.city = 'City required';
      if (!billing.zip.trim()) e.zip = 'ZIP / Postal code required';
    } else {
      if (!paypal.email.trim() || !/^\S+@\S+\.\S+$/.test(paypal.email)) e.paypalEmail = 'Enter a valid PayPal email address';
      if (!paypal.password) e.paypalPassword = 'Enter your PayPal password';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handlePay = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      // Process payment first
      const paymentMethod = method === 'card'
        ? `${getCardType(card.number)} ending ${card.number.replace(/\s/g,'').slice(-4)}`
        : `PayPal (${paypal.email.trim().toLowerCase()})`;

      if (method === 'card') {
        await api.post<any>('/api/payments/process', { cardNumber: card.number, amount: grandTotal });
      } else {
        await api.post<any>('/api/payments/paypal', { email: paypal.email, amount: grandTotal });
      }

      // Then create booking
      const guestDetails = JSON.parse(sessionStorage.getItem('guest-details') || '{}');
      const bookingRes = await api.post<any>('/api/bookings', {
        hotelId: draft.hotel.id,
        roomId: draft.room.id,
        checkIn: draft.checkIn,
        checkOut: draft.checkOut,
        guests: draft.guests,
        nights: draft.nights,
        totalPrice: grandTotal,
        paymentMethod,
        guestDetails,
      });

      paidRef.current = true;
      clearDraft();
      toast.success('Booking Confirmed!', `Reference: ${bookingRes.data.referenceNumber}`);
      router.push(`/booking/confirmation/${bookingRes.data.id}`);
    } catch (err: any) {
      toast.error('Payment failed', err.message);
      setErrors({ payment: err.message });
      setLoading(false);
    }
  };

  const getCardType = (num: string) => {
    const n = num.replace(/\s/g,'');
    if (n.startsWith('4')) return 'Visa';
    if (n.startsWith('5')) return 'Mastercard';
    if (n.startsWith('3')) return 'Amex';
    return 'Card';
  };

  const testCards = [
    { label: 'Success', num: '4242 4242 4242 4242', desc: 'Visa · Always succeeds' },
    { label: 'Declined', num: '4000 0000 0000 0002', desc: 'Visa · Card declined' },
    { label: 'No Funds', num: '4000 0000 0000 9995', desc: 'Visa · Insufficient funds' },
    { label: 'Expired', num: '4000 0000 0000 0069', desc: 'Visa · Card expired' },
  ];

  const testPaypalAccounts = [
    { label: 'Success', email: 'sandbox@paypal.com', desc: 'Always approves' },
    { label: 'Declined', email: 'declined@paypal.com', desc: 'Payment declined' },
    { label: 'No Funds', email: 'nofunds@paypal.com', desc: 'Insufficient balance' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '28px', fontSize: '13px', color: 'var(--text-muted)' }}>
          <span>Review</span><span>›</span><span style={{ color: 'var(--accent)', fontWeight: 600 }}>Payment</span><span>›</span><span>Confirmation</span>
        </div>

        <h1 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '28px', marginBottom: '24px' }}>Secure Payment</h1>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '28px' }}>
          <div>
            {/* Payment method toggle */}
            <div data-testid="payment-method-toggle" style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
              <button
                data-testid="payment-method-card"
                onClick={() => setMethod('card')}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                  padding: '14px', borderRadius: '12px', cursor: 'pointer', fontWeight: 600, fontSize: '14px',
                  background: method === 'card' ? 'var(--accent-light)' : 'var(--surface)',
                  border: method === 'card' ? '2px solid var(--accent)' : '1px solid var(--border)',
                  color: method === 'card' ? 'var(--accent-dark)' : 'var(--text)',
                }}>
                <CreditCard size={17} />Credit / Debit Card
              </button>
              <button
                data-testid="payment-method-paypal"
                onClick={() => setMethod('paypal')}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                  padding: '14px', borderRadius: '12px', cursor: 'pointer', fontWeight: 600, fontSize: '14px',
                  background: method === 'paypal' ? '#eaf4fc' : 'var(--surface)',
                  border: method === 'paypal' ? '2px solid #009cde' : '1px solid var(--border)',
                  color: method === 'paypal' ? '#003087' : 'var(--text)',
                }}>
                <PayPalMark size={16} />
              </button>
            </div>

            {errors.payment && (
              <div data-testid="payment-error" style={{ background: 'var(--error-light)', border: '1px solid var(--error)', borderRadius: '8px', padding: '12px', color: 'var(--error)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <AlertCircle size={16} />{errors.payment}
              </div>
            )}

            {method === 'card' ? (
              <>
                {/* Test cards notice */}
                <div style={{ background: 'var(--warning-light)', border: '1px solid #e8c35a', borderRadius: '10px', padding: '16px', marginBottom: '20px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 700, marginBottom: '10px', color: 'var(--warning)' }}>
                    <AlertCircle size={16} />Test Card Numbers
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px,1fr))', gap: '8px' }}>
                    {testCards.map(tc => (
                      <button key={tc.num} data-testid={`test-card-${tc.label.toLowerCase()}`} onClick={() => setCard(c => ({ ...c, number: tc.num, expiry: '12/28', cvv: '123', holder: c.holder || 'Test User' }))}
                        style={{ background: 'white', border: '1px solid #e8c35a', borderRadius: '8px', padding: '10px', cursor: 'pointer', textAlign: 'left' }}>
                        <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text)' }}>{tc.label}</div>
                        <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'monospace' }}>{tc.num}</div>
                        <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{tc.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Card Form */}
                <div className="card" style={{ padding: '24px', marginBottom: '20px' }} data-testid="payment-form">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', marginBottom: '20px' }}>
                    <CreditCard size={20} color="var(--accent)" />Card Details
                  </div>

                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Cardholder Name</label>
                    <input data-testid="card-holder" className={`input-field ${errors.holder ? 'error' : ''}`} value={card.holder} onChange={e => setCard(c => ({ ...c, holder: e.target.value }))} placeholder="Alex Johnson" autoComplete="cc-name" />
                    {errors.holder && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.holder}</p>}
                  </div>

                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Card Number</label>
                    <div style={{ position: 'relative' }}>
                      <input data-testid="card-number" className={`input-field ${errors.number ? 'error' : ''}`} value={card.number} onChange={e => setCard(c => ({ ...c, number: formatCardNumber(e.target.value) }))} placeholder="1234 5678 9012 3456" maxLength={19} autoComplete="cc-number" style={{ letterSpacing: '2px', fontFamily: 'monospace', paddingRight: '60px' }} />
                      {card.number && <span style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', fontSize: '12px', fontWeight: 700, color: getCardType(card.number) === 'Visa' ? '#1a1f71' : '#eb001b' }}>{getCardType(card.number)}</span>}
                    </div>
                    {errors.number && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.number}</p>}
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                    <div>
                      <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Expiry Date</label>
                      <input data-testid="card-expiry" className={`input-field ${errors.expiry ? 'error' : ''}`} value={card.expiry} onChange={e => {
                        let v = e.target.value.replace(/\D/g,'');
                        if (v.length >= 2) v = v.slice(0,2) + '/' + v.slice(2,4);
                        setCard(c => ({ ...c, expiry: v }));
                      }} placeholder="MM/YY" maxLength={5} autoComplete="cc-exp" />
                      {errors.expiry && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.expiry}</p>}
                    </div>
                    <div>
                      <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>CVV</label>
                      <input data-testid="card-cvv" className={`input-field ${errors.cvv ? 'error' : ''}`} value={card.cvv} onChange={e => setCard(c => ({ ...c, cvv: e.target.value.replace(/\D/g,'').slice(0,4) }))} placeholder="123" maxLength={4} autoComplete="cc-csc" type="password" />
                      {errors.cvv && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.cvv}</p>}
                    </div>
                  </div>

                  <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px', cursor: 'pointer' }}>
                    <input data-testid="save-card" type="checkbox" checked={saveCard} onChange={e => setSaveCard(e.target.checked)} style={{ accentColor: 'var(--accent)', width: '15px', height: '15px' }} />
                    Save card for future bookings
                  </label>
                </div>

                {/* Billing */}
                <div className="card" style={{ padding: '24px' }} data-testid="billing-form">
                  <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', marginBottom: '20px' }}>Billing Address</h3>
                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Street Address</label>
                    <input data-testid="billing-street" className={`input-field ${errors.street ? 'error' : ''}`} value={billing.street} onChange={e => setBilling(b => ({ ...b, street: e.target.value }))} placeholder="123 Main St" />
                    {errors.street && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.street}</p>}
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                    <div>
                      <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>City</label>
                      <input data-testid="billing-city" className={`input-field ${errors.city ? 'error' : ''}`} value={billing.city} onChange={e => setBilling(b => ({ ...b, city: e.target.value }))} placeholder="New York" />
                      {errors.city && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.city}</p>}
                    </div>
                    <div>
                      <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>State</label>
                      <input data-testid="billing-state" className="input-field" value={billing.state} onChange={e => setBilling(b => ({ ...b, state: e.target.value }))} placeholder="New York" />
                    </div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                    <div>
                      <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>ZIP / Postal Code</label>
                      <input data-testid="billing-zip" className={`input-field ${errors.zip ? 'error' : ''}`} value={billing.zip} onChange={e => setBilling(b => ({ ...b, zip: e.target.value }))} placeholder="10001" />
                      {errors.zip && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.zip}</p>}
                    </div>
                    <div>
                      <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Country</label>
                      <select data-testid="billing-country" className="input-field" value={billing.country} onChange={e => setBilling(b => ({ ...b, country: e.target.value }))}>
                        {['United States','Canada','United Kingdom','Australia','Mexico'].map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Test PayPal accounts notice */}
                <div style={{ background: 'var(--warning-light)', border: '1px solid #e8c35a', borderRadius: '10px', padding: '16px', marginBottom: '20px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 700, marginBottom: '10px', color: 'var(--warning)' }}>
                    <AlertCircle size={16} />Test PayPal Accounts
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '8px' }}>
                    {testPaypalAccounts.map(ta => (
                      <button key={ta.email} data-testid={`test-paypal-${ta.label.toLowerCase().replace(' ', '-')}`} onClick={() => setPaypal({ email: ta.email, password: 'sandbox123' })}
                        style={{ background: 'white', border: '1px solid #e8c35a', borderRadius: '8px', padding: '10px', cursor: 'pointer', textAlign: 'left' }}>
                        <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text)' }}>{ta.label}</div>
                        <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'monospace' }}>{ta.email}</div>
                        <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{ta.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Mock PayPal login panel */}
                <div className="card" style={{ padding: '24px' }} data-testid="paypal-form">
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', marginBottom: '20px', paddingBottom: '20px', borderBottom: '1px solid var(--border-soft)' }}>
                    <PayPalMark size={26} />
                    <p style={{ color: 'var(--text-muted)', fontSize: '13px', marginTop: '8px' }}>
                      You&apos;ll be redirected to PayPal to approve this payment.
                    </p>
                  </div>

                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Email or mobile number</label>
                    <input data-testid="paypal-email" className={`input-field ${errors.paypalEmail ? 'error' : ''}`} value={paypal.email} onChange={e => setPaypal(p => ({ ...p, email: e.target.value }))} placeholder="you@example.com" autoComplete="username" />
                    {errors.paypalEmail && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.paypalEmail}</p>}
                  </div>

                  <div style={{ marginBottom: '4px' }}>
                    <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Password</label>
                    <input data-testid="paypal-password" type="password" className={`input-field ${errors.paypalPassword ? 'error' : ''}`} value={paypal.password} onChange={e => setPaypal(p => ({ ...p, password: e.target.value }))} placeholder="Password" autoComplete="current-password" />
                    {errors.paypalPassword && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.paypalPassword}</p>}
                  </div>
                </div>
              </>
            )}

            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '20px', alignItems: 'center' }}>
              <button data-testid="back-to-review" onClick={() => router.back()} className="btn-secondary"><ArrowLeft size={16} />Back</button>
              <button data-testid="pay-now" onClick={handlePay} className="btn-primary" disabled={loading} style={{ padding: '12px 32px', fontSize: '16px' }}>
                {loading ? (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ width: '16px', height: '16px', border: '2px solid rgba(255,255,255,0.3)', borderTopColor: 'white', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} />
                    Processing…
                  </span>
                ) : method === 'card' ? <><Lock size={16} />Pay {formatCurrency(grandTotal)}</> : <>Continue with PayPal · {formatCurrency(grandTotal)}</>}
              </button>
            </div>
          </div>

          {/* Order Summary */}
          <div>
            <div className="card" style={{ padding: '24px', position: 'sticky', top: '80px' }} data-testid="order-summary">
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', marginBottom: '16px' }}>Order Summary</h3>
              <div style={{ display: 'flex', gap: '12px', marginBottom: '16px', paddingBottom: '16px', borderBottom: '1px solid var(--border)' }}>
                <img src={draft.hotel.images[0]} alt={draft.hotel.name} style={{ width: '64px', height: '50px', objectFit: 'cover', borderRadius: '6px' }} />
                <div>
                  <div style={{ fontWeight: 600, fontSize: '14px' }}>{draft.hotel.name}</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{draft.room.name}</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{draft.nights} nights</div>
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '14px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Room ({draft.nights} nights)</span><span>{formatCurrency(draft.totalPrice)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)' }}>
                  <span>Taxes &amp; Fees (12%)</span><span>{formatCurrency(taxes)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)' }}>
                  <span>Service fee</span><span>{formatCurrency(299)}</span>
                </div>
                <div style={{ borderTop: '2px solid var(--border)', paddingTop: '10px', display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '18px' }}>
                  <span>Total</span><span style={{ color: 'var(--accent)' }}>{formatCurrency(grandTotal)}</span>
                </div>
              </div>
              <div style={{ marginTop: '16px', fontSize: '12px', color: 'var(--text-muted)', display: 'flex', alignItems: 'flex-start', gap: '6px' }}>
                <Lock size={12} style={{ marginTop: '2px', flexShrink: 0 }} />
                Your payment is secured with 256-bit SSL encryption.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
