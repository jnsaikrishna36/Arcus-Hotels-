'use client';
import { useRouter } from 'next/navigation';
import { useBookingStore } from '@/lib/stores/booking';
import { useAuthStore } from '@/lib/stores/auth';
import { Navbar } from '@/components/layout/Navbar';
import { formatCurrency, formatDate } from '@/lib/utils';
import { useState, useEffect } from 'react';
import { Hotel, MapPin, Users, Calendar, ArrowRight, ArrowLeft } from 'lucide-react';

export default function ReviewPage() {
  const router = useRouter();
  const { draft } = useBookingStore();
  const { user } = useAuthStore();
  const [form, setForm] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    specialRequests: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!draft) router.push('/hotels/search');
  }, [draft, router]);

  if (!draft) return null;

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.firstName.trim()) e.firstName = 'Required';
    if (!form.lastName.trim()) e.lastName = 'Required';
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Valid email required';
    if (!form.phone) e.phone = 'Required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleContinue = () => {
    if (!validate()) return;
    // Store guest details in sessionStorage for payment page
    sessionStorage.setItem('guest-details', JSON.stringify(form));
    router.push('/booking/payment');
  };

  const taxes = Math.round(draft.totalPrice * 0.12);
  const fees = 25;
  const grandTotal = draft.totalPrice + taxes + fees;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '32px 24px' }}>
        {/* Breadcrumb */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '28px', fontSize: '13px', color: 'var(--text-muted)' }}>
          <span>Search</span><span>›</span><span>Hotel Details</span><span>›</span>
          <span style={{ color: 'var(--accent)', fontWeight: 600 }}>Review</span><span>›</span>
          <span>Payment</span><span>›</span><span>Confirmation</span>
        </div>

        <h1 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '28px', marginBottom: '24px' }}>Review Your Booking</h1>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '28px' }}>
          <div>
            {/* Hotel Summary */}
            <div className="card" style={{ padding: '24px', marginBottom: '20px' }} data-testid="booking-hotel-summary">
              <div style={{ display: 'flex', gap: '16px' }}>
                <img src={draft.hotel.images[0]} alt={draft.hotel.name} style={{ width: '100px', height: '80px', objectFit: 'cover', borderRadius: '8px' }} />
                <div>
                  <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', fontWeight: 600 }}>{draft.hotel.name}</h3>
                  <div style={{ color: 'var(--text-muted)', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <MapPin size={12} />{draft.hotel.city}
                  </div>
                  <div style={{ marginTop: '8px', fontSize: '14px' }}>
                    <strong>{draft.room.name}</strong> · {draft.room.type}
                  </div>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '16px', marginTop: '20px', paddingTop: '20px', borderTop: '1px solid var(--border)' }}>
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, marginBottom: '4px' }}>Check-in</div>
                  <div data-testid="review-checkin" style={{ fontWeight: 600 }}>{formatDate(draft.checkIn, 'dd MMM yyyy')}</div>
                </div>
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, marginBottom: '4px' }}>Check-out</div>
                  <div data-testid="review-checkout" style={{ fontWeight: 600 }}>{formatDate(draft.checkOut, 'dd MMM yyyy')}</div>
                </div>
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, marginBottom: '4px' }}>Duration</div>
                  <div style={{ fontWeight: 600 }}>{draft.nights} night{draft.nights > 1 ? 's' : ''} · {draft.guests} guest{draft.guests > 1 ? 's' : ''}</div>
                </div>
              </div>
            </div>

            {/* Guest Details Form */}
            <div className="card" style={{ padding: '24px' }} data-testid="guest-details-form">
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', marginBottom: '20px' }}>Guest Details</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div>
                  <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>First Name *</label>
                  <input data-testid="guest-firstname" className={`input-field ${errors.firstName ? 'error' : ''}`} value={form.firstName} onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))} placeholder="Alex" />
                  {errors.firstName && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.firstName}</p>}
                </div>
                <div>
                  <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Last Name *</label>
                  <input data-testid="guest-lastname" className={`input-field ${errors.lastName ? 'error' : ''}`} value={form.lastName} onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))} placeholder="Johnson" />
                  {errors.lastName && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.lastName}</p>}
                </div>
              </div>
              <div style={{ marginTop: '16px' }}>
                <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Email *</label>
                <input data-testid="guest-email" type="email" className={`input-field ${errors.email ? 'error' : ''}`} value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="alex@example.com" />
                {errors.email && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.email}</p>}
              </div>
              <div style={{ marginTop: '16px' }}>
                <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Phone *</label>
                <input data-testid="guest-phone" type="tel" className={`input-field ${errors.phone ? 'error' : ''}`} value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+1 (555) 867-5309" />
                {errors.phone && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.phone}</p>}
              </div>
              <div style={{ marginTop: '16px' }}>
                <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Special Requests <span style={{ fontWeight: 400, color: 'var(--text-muted)' }}>(optional)</span></label>
                <textarea data-testid="guest-requests" className="input-field" rows={3} value={form.specialRequests} onChange={e => setForm(f => ({ ...f, specialRequests: e.target.value }))} placeholder="Late check-in, extra pillows, dietary requirements…" style={{ resize: 'vertical' }} />
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '20px' }}>
              <button data-testid="back-btn" onClick={() => router.back()} className="btn-secondary">
                <ArrowLeft size={16} />Back
              </button>
              <button data-testid="continue-to-payment" onClick={handleContinue} className="btn-primary">
                Continue to Payment <ArrowRight size={16} />
              </button>
            </div>
          </div>

          {/* Price Summary */}
          <div>
            <div className="card" style={{ padding: '24px', position: 'sticky', top: '80px' }} data-testid="price-summary">
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', marginBottom: '20px' }}>Price Summary</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '14px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>{formatCurrency(draft.room.pricePerNight)} × {draft.nights} nights</span>
                  <span data-testid="base-price">{formatCurrency(draft.totalPrice)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)' }}>
                  <span>Taxes &amp; Fees (12%)</span>
                  <span data-testid="tax-amount">{formatCurrency(taxes)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)' }}>
                  <span>Service fee</span>
                  <span data-testid="service-fee">{formatCurrency(fees)}</span>
                </div>
                <div style={{ borderTop: '2px solid var(--border)', paddingTop: '12px', display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '18px' }}>
                  <span>Total</span>
                  <span data-testid="grand-total" style={{ color: 'var(--accent)' }}>{formatCurrency(grandTotal)}</span>
                </div>
              </div>
              <div style={{ marginTop: '16px', fontSize: '12px', color: 'var(--text-muted)', background: 'var(--surface-alt)', padding: '10px', borderRadius: '8px' }}>
                ✓ Free cancellation until 48 hours before check-in
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
