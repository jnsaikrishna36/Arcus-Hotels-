import { NextRequest } from 'next/server';

export async function POST(request: NextRequest) {
  const body = await request.json();
  if (!body.email) {
    return Response.json(
      { success: false, message: 'Email is required' },
      { status: 400 }
    );
  }

  return Response.json({
    success: true,
    message: 'Password reset link sent to your email',
  });
}
