import { NextRequest } from 'next/server';
import { findByEmail, addUser, generateToken } from '@/lib/server/user-store';
import { User } from '@/types';
import { randomUUID } from 'crypto';

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { firstName, lastName, email, phone, password } = body;

  if (!firstName || !lastName || !email || !phone || !password) {
    return Response.json(
      { success: false, message: 'All fields are required' },
      { status: 400 }
    );
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return Response.json(
      { success: false, message: 'Please enter a valid email address' },
      { status: 400 }
    );
  }

  if (findByEmail(email)) {
    return Response.json(
      { success: false, message: 'An account with this email already exists' },
      { status: 409 }
    );
  }

  const newUser: User & { password: string } = {
    id: randomUUID(),
    firstName,
    lastName,
    email,
    phone,
    password,
    role: 'user',
    createdAt: new Date().toISOString(),
  };
  addUser(newUser);

  const { password: _pw, ...safeUser } = newUser;
  const token = generateToken(newUser.id);

  return Response.json(
    { success: true, message: 'Account created successfully', data: { user: safeUser, token } },
    { status: 201 }
  );
}
