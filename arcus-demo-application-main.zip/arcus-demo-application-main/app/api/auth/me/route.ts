import { NextRequest } from 'next/server';
import { findById, parseToken } from '@/lib/server/user-store';

export async function GET(request: NextRequest) {
  const auth = request.headers.get('Authorization');
  if (!auth) {
    return Response.json({ success: false, message: 'Unauthorized' }, { status: 401 });
  }

  const parsed = parseToken(auth.replace('Bearer ', ''));
  if (!parsed) {
    return Response.json({ success: false, message: 'Invalid token' }, { status: 401 });
  }

  const user = findById(parsed.userId);
  if (!user) {
    return Response.json({ success: false, message: 'User not found' }, { status: 404 });
  }

  const { password: _pw, ...safeUser } = user;
  return Response.json({ success: true, data: safeUser });
}
