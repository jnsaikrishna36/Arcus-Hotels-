import { NextRequest } from 'next/server';
import { findByEmail, generateToken } from '@/lib/server/user-store';

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { email, password } = body;

  if (!email || !password) {
    return Response.json(
      { success: false, message: 'Email and password are required' },
      { status: 400 }
    );
  }

  const user = findByEmail(email);
  if (!user) {
    return Response.json(
      { success: false, message: 'No account found with this email address' },
      { status: 401 }
    );
  }

  if (user.password !== password) {
    return Response.json(
      { success: false, message: 'Incorrect password. Please try again.' },
      { status: 401 }
    );
  }

  const { password: _pw, ...safeUser } = user;
  const token = generateToken(user.id);

  return Response.json({
    success: true,
    message: 'Login successful',
    data: { user: safeUser, token },
  });
}
