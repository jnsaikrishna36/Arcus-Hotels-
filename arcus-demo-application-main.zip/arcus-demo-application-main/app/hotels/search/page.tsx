'use client';
import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { Navbar } from '@/components/layout/Navbar';
import { api } from '@/lib/api';
import { formatCurrency } from '@/lib/utils';
import { Hotel } from '@/types';
import { Star, MapPin, Wifi, Filter, SlidersHorizontal, Search, Users, Calendar } from 'lucide-react';
import { format, addDays, parseISO } from 'date-fns';
import { CitySelect } from '@/components/search/CitySelect';
import { DateField } from '@/components/search/DateField';
import { GuestSelect } from '@/components/search/GuestSelect';

const HOTEL_IMG_POOL = [
  'photo-1445019980597-93fa8acb246c','photo-1496417263034-38ec4f0b665a','photo-1449844908441-8829872d2607',
  'photo-1504280390367-361c6d9f38f4','photo-1512918728675-ed5a9ecdebfd','photo-1522771739844-6a9f6d5f14af',
  'photo-1631049552240-59c37f38802b','photo-1506059612708-99d6c258160e','photo-1618220179428-22790b461013',
  'photo-1560185007-cde436f6a4d0','photo-1613490493576-7fde63acd811','photo-1566195992011-5f6b21e539aa','photo-1542314831-068cd1dbfeeb','photo-1566073771259-6a8506099945',
  'photo-1583212292454-1fe6229603b7','photo-1600011689032-8b628b8a8747','photo-1455587734955-081b22074882',
  'photo-1551882547-ff40c63fe5fa','photo-1571003123894-1f0594d2b5d9','photo-1578645510447-e20b4311e3ce',
  'photo-1519167758481-83f550bb49b3','photo-1499793983690-e29da59ef1c2','photo-1590073844006-33379778ae09',
  'photo-1610641818989-c2051b5e2cfd','photo-1596436889106-be35e843f974','photo-1590523741831-ab7e8b8f9c7f',
  'photo-1625244724120-1fd1d34d00f6','photo-1611892440504-42a792e24d32','photo-1618773928121-c32242e63f39',
  'photo-1590073242678-70ee3fc28e8e','photo-1582719478250-c89cae4dc85b','photo-1570168007204-dfb528c6958f',
  'photo-1549465220-1a8b9238cd48','photo-1596178065887-1198b6148b2b','photo-1514222709107-a180c68d72b4',
  'photo-1586611292717-f828b167408c','photo-1477959858617-67f85cf4f1df','photo-1535827841776-24afc1e255ac',
  'photo-1541971875076-8f970d573be6','photo-1564078516393-cf04bd966897','photo-1548802673-380ab8ebc7b7',
  'photo-1506905925346-21bda4d32df4','photo-1533174072545-7a4b6ad7a6c3',
  'photo-1615869442320-fd02a129c77c','photo-1531971589569-0d9370cbe1e5','photo-1490122417551-6ee9691429d0',
  'photo-1440778303588-435521a205bc','photo-1426122402199-be02db90eb90','photo-1502005229762-cf1b2da7c5d6',
  'photo-1543968996-ee822b8176ba','photo-1559511260-66a654ae982a','photo-1584132967334-10e028bd69f7',
  'photo-1587381420270-3e1a5b9e6904','photo-1592229505726-ca121723b8ef','photo-1602002418082-a4443e081dd1',
  'photo-1615460549969-36fa19521a4f','photo-1628592102751-ba83b0314276','photo-1631049421450-348ccd7f8949',
  'photo-1564501049412-61c2a3083791','photo-1571896349842-33c89424de2d','photo-1582719508461-905c673771fd',
  'photo-1578683010236-d716f9a3f461','photo-1520250497591-112f2f40a3f4','photo-1559827260-dc66d52bef19',
  'photo-1631049307264-da0ec9d70304',
].map(id => `https://images.unsplash.com/${id}?w=800&h=500&fit=crop&auto=format`);

function hotelImg(hotel: Hotel): string {
  const num = parseInt(hotel.id.replace('hotel-', ''), 10) - 1;
  return HOTEL_IMG_POOL[num % HOTEL_IMG_POOL.length];
}

function HotelCard({ hotel, checkIn, checkOut, guests }: { hotel: Hotel; checkIn: string; checkOut: string; guests: number }) {
  const router = useRouter();
  const params = new URLSearchParams({ checkIn, checkOut, guests: String(guests) });
  return (
    <div data-testid={`hotel-card-${hotel.id}`} className="card" style={{ overflow: 'hidden', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer' }}
      onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = 'var(--shadow-lg)'; }}
      onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'var(--shadow)'; }}
      onClick={() => router.push(`/hotels/${hotel.id}?${params}`)}>
      <div style={{ height: '200px', overflow: 'hidden', background: 'var(--surface-alt)' }}>
        <img src={hotelImg(hotel)} alt={hotel.name} style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.3s' }}
          onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.05)')}
          onMouseLeave={e => (e.currentTarget.style.transform = 'none')} />
      </div>
      <div style={{ padding: '18px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
          <div>
            <h3 data-testid="hotel-name" style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', fontWeight: 600, marginBottom: '4px' }}>{hotel.name}</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--text-muted)', fontSize: '13px' }}>
              <MapPin size={12} />{hotel.city}, {hotel.country}
            </div>
          </div>
          <span className={`badge ${hotel.category === 'luxury' ? 'badge-warning' : hotel.category === 'budget' ? 'badge-neutral' : 'badge-success'}`} style={{ textTransform: 'capitalize' }}>
            {hotel.category}
          </span>
        </div>
        <p style={{ fontSize: '13px', color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: '12px', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
          {hotel.description}
        </p>
        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '14px' }}>
          {hotel.amenities.slice(0, 4).map(a => (
            <span key={a} style={{ fontSize: '11px', background: 'var(--surface-alt)', padding: '3px 8px', borderRadius: '999px', color: 'var(--text-muted)' }}>{a}</span>
          ))}
          {hotel.amenities.length > 4 && <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>+{hotel.amenities.length - 4} more</span>}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid var(--border)', paddingTop: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <Star size={14} fill="#f59e0b" color="#f59e0b" />
            <span data-testid="hotel-rating" style={{ fontWeight: 700, fontSize: '14px' }}>{hotel.rating}</span>
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>({hotel.reviewCount.toLocaleString()})</span>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>From</div>
            <div data-testid="hotel-price" style={{ fontWeight: 700, fontSize: '18px', color: 'var(--accent)' }}>{formatCurrency(hotel.pricePerNight)}</div>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>/night</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SearchContent() {
  const sp = useSearchParams();
  const today = new Date();
  const [filters, setFilters] = useState({
    city: sp.get('city') || '',
    checkIn: sp.get('checkIn') || format(addDays(today, 1), 'yyyy-MM-dd'),
    checkOut: sp.get('checkOut') || format(addDays(today, 3), 'yyyy-MM-dd'),
    guests: parseInt(sp.get('guests') || '2'),
    sort: 'recommended',
    category: '',
    minPrice: 0,
    maxPrice: 2000,
    page: 1,
  });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['hotels', filters],
    queryFn: () => {
      const p = new URLSearchParams({ city: filters.city, guests: String(filters.guests), sort: filters.sort, category: filters.category, minPrice: String(filters.minPrice), maxPrice: String(filters.maxPrice), page: String(filters.page), limit: '6' });
      return api.get<any>('/api/hotels/search?' + p);
    },
  });

  const hotels: Hotel[] = data?.data || [];
  const total = data?.total || 0;
  const totalPages = data?.totalPages || 1;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      {/* Search bar */}
      <div style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', padding: '16px 24px' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div style={{ flex: '1 1 180px' }}>
            <label style={{ display: 'block', fontSize: '11px', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              <MapPin size={10} style={{ display: 'inline', marginRight: '3px' }} />Destination
            </label>
            <CitySelect
              testId="filter-city"
              value={filters.city}
              onChange={(city) => setFilters(f => ({ ...f, city, page: 1 }))}
              groupedOptions={[
                { group: 'United States', tag: 'US', cities: ['New York','Miami','New Orleans','Chicago','Seattle','Washington DC','Las Vegas','San Francisco'] },
                { group: 'Europe', tag: 'EU', cities: ['Oslo','London','Paris','Amsterdam','Barcelona'] },
              ]}
              align="left"
            />
          </div>
          <div style={{ flex: '1 1 160px' }}>
            <label style={{ display: 'block', fontSize: '11px', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              <Calendar size={10} style={{ display: 'inline', marginRight: '3px' }} />Check-in
            </label>
            <DateField
              testId="filter-checkin"
              role="check-in"
              value={filters.checkIn}
              min={format(today, 'yyyy-MM-dd')}
              rangeStart={filters.checkIn}
              rangeEnd={filters.checkOut}
              onChange={(checkIn) =>
                setFilters(f => {
                  const next = { ...f, checkIn };
                  if (f.checkOut <= checkIn) next.checkOut = format(addDays(parseISO(checkIn), 1), 'yyyy-MM-dd');
                  return next;
                })
              }
            />
          </div>
          <div style={{ flex: '1 1 160px' }}>
            <label style={{ display: 'block', fontSize: '11px', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              <Calendar size={10} style={{ display: 'inline', marginRight: '3px' }} />Check-out
            </label>
            <DateField
              testId="filter-checkout"
              role="check-out"
              value={filters.checkOut}
              min={format(addDays(parseISO(filters.checkIn), 1), 'yyyy-MM-dd')}
              rangeStart={filters.checkIn}
              rangeEnd={filters.checkOut}
              onChange={(checkOut) => setFilters(f => ({ ...f, checkOut }))}
            />
          </div>
          <div style={{ flex: '1 1 150px' }}>
            <label style={{ display: 'block', fontSize: '11px', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              <Users size={10} style={{ display: 'inline', marginRight: '3px' }} />Guests
            </label>
            <GuestSelect
              testId="filter-guests"
              value={filters.guests}
              onChange={(guests) => setFilters(f => ({ ...f, guests, page: 1 }))}
              align="right"
            />
          </div>
        </div>
      </div>

      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '24px', display: 'grid', gridTemplateColumns: '260px 1fr', gap: '24px' }}>
        {/* Sidebar filters */}
        <aside data-testid="filter-sidebar">
          <div className="card" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '20px', fontWeight: 700 }}>
              <SlidersHorizontal size={16} color="var(--accent)" />Filters
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '10px' }}>Sort By</label>
              {[['recommended','Recommended'],['price-asc','Price: Low to High'],['price-desc','Price: High to Low'],['rating','Top Rated']].map(([val,label]) => (
                <label key={val} data-testid={`sort-${val}`} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px', cursor: 'pointer', fontSize: '14px' }}>
                  <input type="radio" name="sort" value={val} checked={filters.sort === val} onChange={() => setFilters(f => ({ ...f, sort: val, page: 1 }))} style={{ accentColor: 'var(--accent)' }} />
                  {label}
                </label>
              ))}
            </div>

            <div style={{ marginBottom: '20px', borderTop: '1px solid var(--border)', paddingTop: '20px' }}>
              <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '10px' }}>Category</label>
              {[['','All'],['budget','Budget'],['standard','Standard'],['deluxe','Deluxe'],['luxury','Luxury']].map(([val,label]) => (
                <label key={val} data-testid={`category-${val||'all'}`} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px', cursor: 'pointer', fontSize: '14px' }}>
                  <input type="radio" name="category" value={val} checked={filters.category === val} onChange={() => setFilters(f => ({ ...f, category: val, page: 1 }))} style={{ accentColor: 'var(--accent)' }} />
                  {label}
                </label>
              ))}
            </div>

            <div style={{ borderTop: '1px solid var(--border)', paddingTop: '20px' }}>
              <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '10px' }}>Max Price / Night</label>
              <input data-testid="filter-max-price" type="range" min="0" max="2000" step="50" value={filters.maxPrice} onChange={e => setFilters(f => ({ ...f, maxPrice: +e.target.value, page: 1 }))} style={{ width: '100%', accentColor: 'var(--accent)' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: 'var(--text-muted)' }}>
                <span>$0</span><span data-testid="max-price-display">${filters.maxPrice.toLocaleString()}</span>
              </div>
            </div>

            <button data-testid="clear-filters" onClick={() => setFilters(f => ({ ...f, sort: 'recommended', category: '', minPrice: 0, maxPrice: 2000, page: 1 }))}
              style={{ marginTop: '16px', width: '100%', padding: '8px', background: 'none', border: '1px solid var(--border)', borderRadius: '8px', cursor: 'pointer', fontSize: '13px', color: 'var(--text-muted)' }}>
              Clear Filters
            </button>
          </div>
        </aside>

        {/* Results */}
        <main>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <div>
              <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '24px', marginBottom: '2px' }}>
                {filters.city ? `Stays in ${filters.city}` : 'All Stays'}
              </h2>
              <p data-testid="results-count" style={{ color: 'var(--text-muted)', fontSize: '14px' }}>
                {isLoading ? 'Searching…' : `${total} propert${total !== 1 ? 'ies' : 'y'} found`}
              </p>
            </div>
          </div>

          {isLoading || isFetching ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: '20px' }}>
              {[1,2,3,4,5,6].map(i => (
                <div key={i} className="card" style={{ overflow: 'hidden' }}>
                  <div className="skeleton" style={{ height: '200px' }} />
                  <div style={{ padding: '18px' }}>
                    <div className="skeleton" style={{ height: '20px', width: '70%', marginBottom: '8px' }} />
                    <div className="skeleton" style={{ height: '14px', width: '40%', marginBottom: '12px' }} />
                    <div className="skeleton" style={{ height: '40px' }} />
                  </div>
                </div>
              ))}
            </div>
          ) : hotels.length === 0 ? (
            <div data-testid="no-results" style={{ textAlign: 'center', padding: '60px 24px', color: 'var(--text-muted)' }}>
              <Search size={40} style={{ opacity: 0.3, marginBottom: '16px' }} />
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '20px', marginBottom: '8px', color: 'var(--text)' }}>No hotels found</h3>
              <p>Try adjusting your search filters or choose a different city.</p>
            </div>
          ) : (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: '20px' }}>
                {hotels.map(h => <HotelCard key={h.id} hotel={h} checkIn={filters.checkIn} checkOut={filters.checkOut} guests={filters.guests} />)}
              </div>
              {/* Pagination */}
              {totalPages > 1 && (
                <div data-testid="pagination" style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '32px' }}>
                  <button data-testid="prev-page" onClick={() => setFilters(f => ({ ...f, page: f.page - 1 }))} disabled={filters.page === 1}
                    style={{ padding: '8px 16px', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--surface)', cursor: filters.page === 1 ? 'not-allowed' : 'pointer', opacity: filters.page === 1 ? 0.4 : 1 }}>
                    ← Prev
                  </button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                    <button key={p} data-testid={`page-${p}`} onClick={() => setFilters(f => ({ ...f, page: p }))}
                      style={{ width: '36px', height: '36px', border: '1px solid', borderColor: filters.page === p ? 'var(--accent)' : 'var(--border)', borderRadius: '8px', background: filters.page === p ? 'var(--accent)' : 'var(--surface)', color: filters.page === p ? 'white' : 'var(--text)', cursor: 'pointer', fontWeight: filters.page === p ? 700 : 400 }}>
                      {p}
                    </button>
                  ))}
                  <button data-testid="next-page" onClick={() => setFilters(f => ({ ...f, page: f.page + 1 }))} disabled={filters.page === totalPages}
                    style={{ padding: '8px 16px', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--surface)', cursor: filters.page === totalPages ? 'not-allowed' : 'pointer', opacity: filters.page === totalPages ? 0.4 : 1 }}>
                    Next →
                  </button>
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}

export default function SearchPage() {
  return <Suspense fallback={<div>Loading…</div>}><SearchContent /></Suspense>;
}
