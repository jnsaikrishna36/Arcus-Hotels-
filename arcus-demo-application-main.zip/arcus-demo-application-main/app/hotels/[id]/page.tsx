'use client';
import { useParams, useSearchParams, useRouter } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { Suspense, useState } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { api } from '@/lib/api';
import { formatCurrency, calcNights } from '@/lib/utils';
import { useBookingStore } from '@/lib/stores/booking';
import { useAuthStore } from '@/lib/stores/auth';
import { Hotel, Room } from '@/types';
import { Star, MapPin, Wifi, Check, X, Users, ChevronLeft, ChevronRight } from 'lucide-react';
import { toast } from '@/components/ui/Toaster';

function HotelDetailContent() {
  const { id } = useParams<{ id: string }>();
  const sp = useSearchParams();
  const router = useRouter();
  const { setDraft } = useBookingStore();
  const { isAuthenticated } = useAuthStore();
  const [imgIdx, setImgIdx] = useState(0);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

  const checkIn = sp.get('checkIn') || '';
  const checkOut = sp.get('checkOut') || '';
  const guests = parseInt(sp.get('guests') || '2');
  const nights = calcNights(checkIn, checkOut);

  const { data, isLoading } = useQuery({
    queryKey: ['hotel', id],
    queryFn: () => api.get<{ data: Hotel }>(`/api/hotels/${id}`),
  });

  const hotel: Hotel | undefined = (data as any)?.data;

  const handleBook = (room: Room) => {
    if (!isAuthenticated) {
      toast.info('Please log in', 'You need to be logged in to book');
      const returnTo = encodeURIComponent(window.location.pathname + window.location.search);
      router.push(`/auth/login?callbackUrl=${returnTo}`);
      return;
    }
    if (!checkIn || !checkOut) {
      toast.warning('Select dates', 'Please select check-in and check-out dates');
      return;
    }
    setDraft({ hotel: hotel!, room, checkIn, checkOut, guests, nights, totalPrice: room.pricePerNight * nights });
    router.push('/booking/review');
  };

  if (isLoading || !hotel) {
    return (
      <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
        <Navbar />
        <div style={{ maxWidth: '1200px', margin: '40px auto', padding: '0 24px' }}>
          <div className="skeleton" style={{ height: '400px', borderRadius: '16px', marginBottom: '24px' }} />
          <div className="skeleton" style={{ height: '32px', width: '50%', marginBottom: '12px' }} />
          <div className="skeleton" style={{ height: '20px', width: '30%' }} />
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }} data-testid="hotel-detail">
      <Navbar />
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '32px 24px' }}>
        {/* Back */}
        <button data-testid="back-to-search" onClick={() => router.back()} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '14px', marginBottom: '24px', padding: 0 }}>
          <ChevronLeft size={16} />Back to results
        </button>

        {/* Image Gallery */}
        <div style={{ position: 'relative', height: '420px', borderRadius: '16px', overflow: 'hidden', marginBottom: '32px' }} data-testid="hotel-gallery">
          <img src={hotel.images[imgIdx]} alt={hotel.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          {hotel.images.length > 1 && (
            <>
              <button data-testid="prev-image" onClick={() => setImgIdx(i => (i - 1 + hotel.images.length) % hotel.images.length)}
                style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', background: 'rgba(0,0,0,0.5)', border: 'none', borderRadius: '50%', width: '40px', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white' }}>
                <ChevronLeft size={20} />
              </button>
              <button data-testid="next-image" onClick={() => setImgIdx(i => (i + 1) % hotel.images.length)}
                style={{ position: 'absolute', right: '16px', top: '50%', transform: 'translateY(-50%)', background: 'rgba(0,0,0,0.5)', border: 'none', borderRadius: '50%', width: '40px', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white' }}>
                <ChevronRight size={20} />
              </button>
              <div style={{ position: 'absolute', bottom: '16px', left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: '6px' }}>
                {hotel.images.map((_, i) => <div key={i} style={{ width: '8px', height: '8px', borderRadius: '50%', background: i === imgIdx ? 'white' : 'rgba(255,255,255,0.5)' }} />)}
              </div>
            </>
          )}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '32px' }}>
          {/* Left */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
              <div>
                <h1 data-testid="hotel-title" style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '32px', fontWeight: 600, marginBottom: '8px' }}>{hotel.name}</h1>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '14px' }}>
                  <MapPin size={14} />{hotel.address}
                </div>
              </div>
              <span className={`badge ${hotel.category === 'luxury' ? 'badge-warning' : 'badge-neutral'}`} style={{ textTransform: 'capitalize', fontSize: '13px', padding: '6px 14px' }}>{hotel.category}</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                {[1,2,3,4,5].map(s => <Star key={s} size={16} fill={s <= Math.floor(hotel.rating) ? '#f59e0b' : 'none'} color="#f59e0b" />)}
              </div>
              <span data-testid="hotel-rating" style={{ fontWeight: 700, fontSize: '16px' }}>{hotel.rating}</span>
              <span style={{ color: 'var(--text-muted)', fontSize: '14px' }}>({hotel.reviewCount.toLocaleString()} reviews)</span>
            </div>

            <p style={{ fontSize: '15px', lineHeight: 1.7, color: 'var(--text-muted)', marginBottom: '28px' }}>{hotel.description}</p>

            <div style={{ marginBottom: '28px' }}>
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '20px', marginBottom: '14px' }}>Amenities</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(180px,1fr))', gap: '8px' }} data-testid="amenities-list">
                {hotel.amenities.map(a => (
                  <div key={a} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px', padding: '8px', background: 'var(--surface)', borderRadius: '8px', border: '1px solid var(--border)' }}>
                    <Check size={14} color="var(--success)" />{a}
                  </div>
                ))}
              </div>
            </div>

            {/* Rooms */}
            <div>
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '20px', marginBottom: '16px' }}>Available Rooms</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }} data-testid="rooms-list">
                {hotel.rooms.map(room => (
                  <div key={room.id} data-testid={`room-${room.id}`} className="card" style={{ padding: '20px', opacity: room.available ? 1 : 0.6 }}>
                    <div style={{ display: 'flex', gap: '16px' }}>
                      <img src={room.images[0]} alt={room.name} style={{ width: '120px', height: '90px', objectFit: 'cover', borderRadius: '8px' }} />
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                          <div>
                            <h4 data-testid="room-name" style={{ fontWeight: 700, fontSize: '16px', marginBottom: '4px' }}>{room.name}</h4>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--text-muted)', fontSize: '13px', marginBottom: '8px' }}>
                              <Users size={12} />Up to {room.capacity} guests
                            </div>
                            <p style={{ fontSize: '13px', color: 'var(--text-muted)' }}>{room.description}</p>
                            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '8px' }}>
                              {room.amenities.map(a => <span key={a} style={{ fontSize: '11px', background: 'var(--surface-alt)', padding: '2px 8px', borderRadius: '999px' }}>{a}</span>)}
                            </div>
                          </div>
                          <div style={{ textAlign: 'right', minWidth: '140px' }}>
                            <div style={{ fontWeight: 700, fontSize: '20px', color: 'var(--accent)' }}>{formatCurrency(room.pricePerNight)}</div>
                            <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '10px' }}>per night</div>
                            {nights > 0 && <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '10px' }}>{nights} nights = {formatCurrency(room.pricePerNight * nights)}</div>}
                            {room.available ? (
                              <button data-testid={`book-room-${room.id}`} onClick={() => handleBook(room)} className="btn-primary" style={{ fontSize: '13px', padding: '8px 16px' }}>
                                Select Room
                              </button>
                            ) : (
                              <span className="badge badge-error">Unavailable</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Booking summary sidebar */}
          <div>
            <div className="card" style={{ padding: '24px', position: 'sticky', top: '80px' }} data-testid="booking-summary">
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', marginBottom: '20px' }}>Your Stay</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '20px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '6px' }}>Check-in</label>
                  <input data-testid="stay-checkin" type="date" className="input-field" value={checkIn} readOnly />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '6px' }}>Check-out</label>
                  <input data-testid="stay-checkout" type="date" className="input-field" value={checkOut} readOnly />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '6px' }}>Guests</label>
                  <input data-testid="stay-guests" type="number" className="input-field" value={guests} readOnly />
                </div>
              </div>
              {nights > 0 && (
                <div style={{ background: 'var(--surface-alt)', borderRadius: '8px', padding: '14px', fontSize: '14px', color: 'var(--text-muted)' }}>
                  <strong style={{ color: 'var(--text)' }}>{nights} night{nights > 1 ? 's' : ''}</strong> selected. Choose a room above to proceed.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function HotelDetailPage() {
  return <Suspense fallback={<div>Loading…</div>}><HotelDetailContent /></Suspense>;
}
