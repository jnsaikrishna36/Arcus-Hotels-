'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Navbar } from '@/components/layout/Navbar';
import { api } from '@/lib/api';
import { User } from '@/types';
import { getInitials, generateColor, formatDate } from '@/lib/utils';
import { Search, Users, Shield, User as UserIcon } from 'lucide-react';

export default function AdminUsersPage() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const limit = 8;

  const { data, isLoading } = useQuery({
    queryKey: ['admin-users', search, page],
    queryFn: () => api.get<any>(`/api/admin/users?search=${encodeURIComponent(search)}&page=${page}&limit=${limit}`),
  });

  const users: User[] = data?.data || [];
  const total = data?.total || 0;
  const totalPages = data?.totalPages || 1;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '36px 24px' }} data-testid="admin-users-page">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '28px' }}>
          <div>
            <h1 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '28px', marginBottom: '4px' }}>User Management</h1>
            <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>{total} registered user{total !== 1 ? 's' : ''}</p>
          </div>
        </div>

        {/* Search */}
        <div style={{ position: 'relative', maxWidth: '400px', marginBottom: '24px' }}>
          <Search size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input
            data-testid="user-search"
            className="input-field"
            style={{ paddingLeft: '40px' }}
            placeholder="Search by name or email…"
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
          />
        </div>

        {isLoading ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: '14px' }}>
            {[1,2,3,4,5,6].map(i => <div key={i} className="skeleton" style={{ height: '96px', borderRadius: '10px' }} />)}
          </div>
        ) : users.length === 0 ? (
          <div data-testid="no-users" style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
            <Users size={40} style={{ opacity: 0.3, marginBottom: '12px' }} />
            <p>No users found{search ? ` for "${search}"` : ''}.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: '14px' }}>
            {users.map(u => (
              <div key={u.id} data-testid={`user-card-${u.id}`} className="card" style={{ padding: '18px', display: 'flex', gap: '14px', alignItems: 'center' }}>
                <div style={{ width: '46px', height: '46px', borderRadius: '50%', background: generateColor(u.id), color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', fontWeight: 700, flexShrink: 0 }}>
                  {getInitials(u.firstName, u.lastName)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '2px' }}>
                    <span data-testid="user-name" style={{ fontWeight: 700, fontSize: '14px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{u.firstName} {u.lastName}</span>
                    {u.role === 'admin' ? <Shield size={13} color="var(--warning)" /> : <UserIcon size={13} color="var(--text-muted)" />}
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{u.email}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '4px' }}>
                    <span className={`badge ${u.role === 'admin' ? 'badge-warning' : 'badge-neutral'}`} style={{ textTransform: 'capitalize', fontSize: '11px' }}>{u.role}</span>
                    <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Joined {formatDate(u.createdAt, 'MMM yyyy')}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {totalPages > 1 && (
          <div data-testid="users-pagination" style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '28px' }}>
            <button data-testid="prev-page" onClick={() => setPage(p => p - 1)} disabled={page === 1}
              style={{ padding: '8px 16px', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--surface)', cursor: page === 1 ? 'not-allowed' : 'pointer', opacity: page === 1 ? 0.4 : 1 }}>
              ← Prev
            </button>
            <span style={{ padding: '8px 16px', fontSize: '14px', color: 'var(--text-muted)' }}>Page {page} of {totalPages}</span>
            <button data-testid="next-page" onClick={() => setPage(p => p + 1)} disabled={page === totalPages}
              style={{ padding: '8px 16px', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--surface)', cursor: page === totalPages ? 'not-allowed' : 'pointer', opacity: page === totalPages ? 0.4 : 1 }}>
              Next →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
