'use client';
import { useRouter } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { Navbar } from '@/components/layout/Navbar';
import { api } from '@/lib/api';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Booking } from '@/types';
import { Users, BookOpen, TrendingUp, Hotel, ArrowRight, CheckCircle, XCircle, Clock } from 'lucide-react';

function StatCard({ icon, label, value, sub, testid, color = 'var(--accent)' }: any) {
  return (
    <div data-testid={testid} className="card" style={{ padding: '24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <p style={{ fontSize: '13px', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>{label}</p>
          <div style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '32px', fontWeight: 700 }}>{value}</div>
          {sub && <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}>{sub}</p>}
        </div>
        <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: `${color}20`, display: 'flex', alignItems: 'center', justifyContent: 'center', color }}>{icon}</div>
      </div>
    </div>
  );
}

export default function AdminDashboardPage() {
  const router = useRouter();

  const { data: bookingsData } = useQuery({
    queryKey: ['admin-bookings-stats'],
    queryFn: () => api.get<any>('/api/admin/bookings?limit=100'),
  });

  const { data: usersData } = useQuery({
    queryKey: ['admin-users-stats'],
    queryFn: () => api.get<any>('/api/admin/users?limit=100'),
  });

  const allBookings: Booking[] = bookingsData?.data || [];
  const totalUsers = usersData?.total || 0;
  const totalBookings = bookingsData?.total || 0;
  const confirmedBookings = allBookings.filter(b => b.status === 'confirmed').length;
  const cancelledBookings = allBookings.filter(b => b.status === 'cancelled').length;
  const revenue = allBookings.filter(b => b.paymentStatus === 'paid').reduce((s, b) => s + b.totalPrice, 0);
  const recent = allBookings.slice(0, 5);

  const STATUS_ICON: Record<string, React.ReactNode> = {
    confirmed: <CheckCircle size={14} color="var(--success)" />,
    completed: <CheckCircle size={14} color="var(--text-muted)" />,
    cancelled: <XCircle size={14} color="var(--error)" />,
    pending: <Clock size={14} color="var(--warning)" />,
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '36px 24px' }} data-testid="admin-dashboard">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '28px' }}>
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', background: 'var(--error-light)', border: '1px solid var(--error)', borderRadius: '999px', padding: '4px 12px', marginBottom: '10px' }}>
              <span style={{ fontSize: '11px', fontWeight: 700, color: 'var(--error)', textTransform: 'uppercase' }}>Admin Portal</span>
            </div>
            <h1 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '30px' }}>Dashboard Overview</h1>
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button data-testid="admin-users-btn" onClick={() => router.push('/admin/users')} className="btn-secondary" style={{ fontSize: '14px' }}>
              <Users size={15} />Users
            </button>
            <button data-testid="admin-bookings-btn" onClick={() => router.push('/admin/bookings')} className="btn-primary" style={{ fontSize: '14px' }}>
              <BookOpen size={15} />Bookings
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: '16px', marginBottom: '32px' }}>
          <StatCard testid="stat-users" icon={<Users size={22} />} label="Total Users" value={totalUsers} sub="Registered accounts" />
          <StatCard testid="stat-bookings" icon={<BookOpen size={22} />} label="Total Bookings" value={totalBookings} sub={`${confirmedBookings} confirmed`} />
          <StatCard testid="stat-revenue" icon={<TrendingUp size={22} />} label="Total Revenue" value={formatCurrency(revenue)} sub="From paid bookings" color="var(--success)" />
          <StatCard testid="stat-cancelled" icon={<XCircle size={22} />} label="Cancellations" value={cancelledBookings} sub="Cancelled bookings" color="var(--error)" />
        </div>

        {/* Recent Bookings Table */}
        <div className="card" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '20px' }}>Recent Bookings</h2>
            <button data-testid="view-all-bookings" onClick={() => router.push('/admin/bookings')}
              style={{ display: 'flex', alignItems: 'center', gap: '4px', background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', fontWeight: 600, fontSize: '14px' }}>
              View all <ArrowRight size={14} />
            </button>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }} data-testid="recent-bookings-table">
              <thead>
                <tr style={{ borderBottom: '2px solid var(--border)' }}>
                  {['Reference', 'Guest', 'Hotel', 'Check-in', 'Amount', 'Status'].map(h => (
                    <th key={h} style={{ textAlign: 'left', padding: '10px 12px', fontSize: '12px', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recent.map(b => (
                  <tr key={b.id} data-testid={`admin-booking-row-${b.id}`} style={{ borderBottom: '1px solid var(--border)', transition: 'background 0.1s' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface-alt)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '12px' }}><span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--accent)', fontSize: '13px' }}>{b.referenceNumber}</span></td>
                    <td style={{ padding: '12px' }}>{b.guestDetails.firstName} {b.guestDetails.lastName}</td>
                    <td style={{ padding: '12px', maxWidth: '160px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.hotel.name}</td>
                    <td style={{ padding: '12px', color: 'var(--text-muted)' }}>{formatDate(b.checkIn)}</td>
                    <td style={{ padding: '12px', fontWeight: 600 }}>{formatCurrency(b.totalPrice)}</td>
                    <td style={{ padding: '12px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        {STATUS_ICON[b.status]}
                        <span style={{ textTransform: 'capitalize' }}>{b.status}</span>
                      </div>
                    </td>
                  </tr>
                ))}
                {recent.length === 0 && (
                  <tr><td colSpan={6} style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)' }}>No bookings yet</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
