'use client';
import { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Navbar } from '@/components/layout/Navbar';
import { api } from '@/lib/api';
import { Booking } from '@/types';
import { formatCurrency, formatDate } from '@/lib/utils';
import { toast } from '@/components/ui/Toaster';
import { Search, ChevronDown } from 'lucide-react';

const STATUS_OPTIONS = ['confirmed', 'pending', 'completed', 'cancelled'];

function StatusDropdown({ booking, onSelect }: { booking: Booking; onSelect: (status: string) => void }) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ top: 0, right: 0 });
  const btnRef = useRef<HTMLButtonElement>(null);
  const popRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    if (btnRef.current) {
      const r = btnRef.current.getBoundingClientRect();
      setPos({ top: r.bottom + 4, right: window.innerWidth - r.right });
    }
    const onDown = (e: MouseEvent) => {
      if (popRef.current && !popRef.current.contains(e.target as Node) &&
          btnRef.current && !btnRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDown); document.removeEventListener('keydown', onKey); };
  }, [open]);

  return (
    <div style={{ display: 'inline-block' }}>
      <button
        ref={btnRef}
        data-testid={`change-status-${booking.id}`}
        onClick={() => setOpen(o => !o)}
        style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 10px', border: '1px solid var(--border)', borderRadius: '6px', background: 'var(--surface)', cursor: 'pointer', fontSize: '12px', fontWeight: 600 }}>
        Status <ChevronDown size={12} />
      </button>
      {open && (
        <div ref={popRef} style={{ position: 'fixed', top: pos.top, right: pos.right, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '8px', boxShadow: 'var(--shadow-lg)', zIndex: 300, minWidth: '140px', overflow: 'hidden' }}>
          {STATUS_OPTIONS.map(s => (
            <button key={s} data-testid={`set-status-${s}-${booking.id}`}
              onClick={() => { onSelect(s); setOpen(false); }}
              disabled={booking.status === s}
              style={{ display: 'block', width: '100%', textAlign: 'left', padding: '9px 14px', background: booking.status === s ? 'var(--surface-alt)' : 'none', border: 'none', cursor: booking.status === s ? 'default' : 'pointer', fontSize: '13px', textTransform: 'capitalize', color: booking.status === s ? 'var(--text-muted)' : 'var(--text)', fontWeight: booking.status === s ? 700 : 400 }}
              onMouseEnter={e => { if (booking.status !== s) e.currentTarget.style.background = 'var(--accent-light)'; if (booking.status !== s) e.currentTarget.style.color = 'var(--accent-dark)'; }}
              onMouseLeave={e => { if (booking.status !== s) e.currentTarget.style.background = 'none'; if (booking.status !== s) e.currentTarget.style.color = 'var(--text)'; }}>
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AdminBookingsPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const limit = 8;

  const { data, isLoading } = useQuery({
    queryKey: ['admin-bookings', search, statusFilter, page],
    queryFn: () => api.get<any>(`/api/admin/bookings?search=${encodeURIComponent(search)}&status=${statusFilter}&page=${page}&limit=${limit}`),
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) => api.put(`/api/admin/bookings/${id}/status`, { status }),
    onSuccess: (_, vars) => {
      toast.success('Status updated', `Booking updated to "${vars.status}"`);
      qc.invalidateQueries({ queryKey: ['admin-bookings'] });
    },
    onError: (err: any) => toast.error('Update failed', err.message),
  });

  const bookings: Booking[] = data?.data || [];
  const total = data?.total || 0;
  const totalPages = data?.totalPages || 1;

  const STATUS_BADGE: Record<string, string> = {
    confirmed: 'badge-success',
    completed: 'badge-neutral',
    cancelled: 'badge-error',
    pending: 'badge-warning',
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '36px 24px' }} data-testid="admin-bookings-page">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '28px' }}>
          <div>
            <h1 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '28px', marginBottom: '4px' }}>Booking Management</h1>
            <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>{total} total booking{total !== 1 ? 's' : ''}</p>
          </div>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: '12px', marginBottom: '24px', flexWrap: 'wrap' }}>
          <div style={{ position: 'relative', flex: '1 1 300px' }}>
            <Search size={15} style={{ position: 'absolute', left: '13px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input data-testid="booking-search" className="input-field" style={{ paddingLeft: '38px' }}
              placeholder="Search by reference, hotel, or guest email…"
              value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} />
          </div>
          <select data-testid="booking-status-filter" className="input-field" style={{ width: '160px' }}
            value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setPage(1); }}>
            <option value="">All Statuses</option>
            {STATUS_OPTIONS.map(s => <option key={s} value={s} style={{ textTransform: 'capitalize' }}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
          </select>
        </div>

        {isLoading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: '64px', borderRadius: '8px' }} />)}
          </div>
        ) : bookings.length === 0 ? (
          <div data-testid="no-bookings" style={{ textAlign: 'center', padding: '60px', color: 'var(--text-muted)' }}>
            No bookings found{search ? ` for "${search}"` : ''}.
          </div>
        ) : (
          <div className="card" style={{ overflow: 'hidden' }}>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }} data-testid="bookings-table">
                <thead>
                  <tr style={{ borderBottom: '2px solid var(--border)', background: 'var(--surface-alt)' }}>
                    {['Reference','Guest','Hotel','Room','Check-in','Nights','Amount','Status','Actions'].map(h => (
                      <th key={h} style={{ textAlign: 'left', padding: '12px 14px', fontSize: '11px', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {bookings.map(b => (
                    <tr key={b.id} data-testid={`booking-row-${b.id}`} style={{ borderBottom: '1px solid var(--border)', transition: 'background 0.1s' }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface-alt)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <td style={{ padding: '12px 14px' }}>
                        <span data-testid={`ref-${b.id}`} style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--accent)', fontSize: '12px' }}>{b.referenceNumber}</span>
                      </td>
                      <td style={{ padding: '12px 14px' }}>
                        <div style={{ fontWeight: 600, fontSize: '13px' }}>{b.guestDetails.firstName} {b.guestDetails.lastName}</div>
                        <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{b.guestDetails.email}</div>
                      </td>
                      <td style={{ padding: '12px 14px', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.hotel.name}</td>
                      <td style={{ padding: '12px 14px', color: 'var(--text-muted)', fontSize: '13px', maxWidth: '120px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.room.name}</td>
                      <td style={{ padding: '12px 14px', color: 'var(--text-muted)', fontSize: '13px', whiteSpace: 'nowrap' }}>{formatDate(b.checkIn)}</td>
                      <td style={{ padding: '12px 14px', color: 'var(--text-muted)', fontSize: '13px' }}>{b.nights}</td>
                      <td style={{ padding: '12px 14px', fontWeight: 700, whiteSpace: 'nowrap' }}>{formatCurrency(b.totalPrice)}</td>
                      <td style={{ padding: '12px 14px' }}>
                        <span data-testid={`status-${b.id}`} className={`badge ${STATUS_BADGE[b.status] || 'badge-neutral'}`} style={{ textTransform: 'capitalize', whiteSpace: 'nowrap' }}>{b.status}</span>
                      </td>
                      <td style={{ padding: '12px 14px' }}>
                        <StatusDropdown booking={b} onSelect={s => statusMutation.mutate({ id: b.id, status: s })} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {totalPages > 1 && (
          <div data-testid="bookings-pagination" style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '24px' }}>
            <button data-testid="prev-page" onClick={() => setPage(p => p - 1)} disabled={page === 1}
              style={{ padding: '8px 16px', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--surface)', cursor: page === 1 ? 'not-allowed' : 'pointer', opacity: page === 1 ? 0.4 : 1 }}>
              ← Prev
            </button>
            <span style={{ padding: '8px 16px', fontSize: '14px', color: 'var(--text-muted)' }}>Page {page} of {totalPages}</span>
            <button data-testid="next-page" onClick={() => setPage(p => p + 1)} disabled={page === totalPages}
              style={{ padding: '8px 16px', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--surface)', cursor: page === totalPages ? 'not-allowed' : 'pointer', opacity: page === totalPages ? 0.4 : 1 }}>
              Next →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
