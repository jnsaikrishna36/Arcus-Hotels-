'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/lib/stores/auth';
import { toast } from '@/components/ui/Toaster';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, user } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/auth/login');
    } else if (user?.role !== 'admin') {
      toast.error('Access Denied', 'Admin privileges required.');
      router.push('/dashboard');
    }
  }, [isAuthenticated, user]);

  if (!isAuthenticated || user?.role !== 'admin') return null;
  return <>{children}</>;
}
