'use client';
import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Navbar } from '@/components/layout/Navbar';
import { useAuthStore } from '@/lib/stores/auth';
import { api } from '@/lib/api';
import { toast } from '@/components/ui/Toaster';
import { getInitials, generateColor } from '@/lib/utils';
import { User, Mail, Phone, MapPin, Save } from 'lucide-react';

export default function ProfilePage() {
  const { user, updateUser } = useAuthStore();
  const [form, setForm] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: {
      street: user?.address?.street || '',
      city: user?.address?.city || '',
      state: user?.address?.state || '',
      zip: user?.address?.zip || '',
      country: user?.address?.country || 'United States',
    },
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.firstName.trim()) e.firstName = 'Required';
    if (!form.lastName.trim()) e.lastName = 'Required';
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Valid email required';
    if (!form.phone) e.phone = 'Required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const mutation = useMutation({
    mutationFn: () => api.put<any>('/api/auth/profile', form),
    onSuccess: (res) => {
      updateUser(res.data);
      toast.success('Profile updated', 'Your changes have been saved.');
    },
    onError: (err: any) => toast.error('Update failed', err.message),
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    mutation.mutate();
  };

  const f = (name: string, label: string, icon: React.ReactNode, type = 'text', placeholder = '') => {
    const isAddr = name.startsWith('address.');
    const key = isAddr ? name.split('.')[1] : name;
    const value = isAddr ? (form.address as any)[key] : (form as any)[key];
    const onChange = isAddr
      ? (v: string) => setForm(f => ({ ...f, address: { ...f.address, [key]: v } }))
      : (v: string) => { setForm(f => ({ ...f, [key]: v })); setErrors(e => ({ ...e, [key]: '' })); };
    return (
      <div>
        <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>{label}</label>
        <div style={{ position: 'relative' }}>
          <span style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }}>{icon}</span>
          <input
            data-testid={`profile-${name.replace('.', '-')}`}
            type={type}
            className={`input-field ${errors[key] ? 'error' : ''}`}
            style={{ paddingLeft: '40px' }}
            value={value}
            onChange={e => onChange(e.target.value)}
            placeholder={placeholder}
          />
        </div>
        {errors[key] && <p style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors[key]}</p>}
      </div>
    );
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />

      {/* Hero Banner */}
      <div style={{
        background: 'linear-gradient(180deg,#0d1b3e 0%,#22356b 34%,#4a5d97 60%,#a9806f 84%,#e7b98f 100%)',
        height: '172px',
        overflow: 'hidden',
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
      }}>
        <div style={{
          position: 'absolute', top: '50%', left: '60%', transform: 'translate(-50%,-50%)',
          width: '600px', height: '600px',
          background: 'radial-gradient(circle, rgba(0,178,189,0.18) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{ maxWidth: '700px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1, width: '100%' }}>
          <h1 style={{
            fontFamily: "'Bricolage Grotesque','Inter',sans-serif",
            fontSize: 'clamp(26px,3vw,34px)',
            fontWeight: 800,
            color: '#fff',
            margin: 0,
            marginBottom: '6px',
          }}>
            My Profile
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.72)', margin: 0, fontSize: '15px' }}>
            Manage your personal information
          </p>
        </div>
      </div>

      <div style={{ maxWidth: '700px', margin: '0 auto', padding: '0 24px 60px' }} data-testid="profile-page">

        {/* Avatar Card */}
        <div style={{
          background: 'var(--surface)',
          borderRadius: '18px',
          boxShadow: 'var(--shadow)',
          padding: '28px',
          marginTop: '28px',
          marginBottom: '20px',
          display: 'flex',
          alignItems: 'center',
          gap: '24px',
          border: '1px solid var(--border)',
        }}>
          <div style={{
            width: '80px', height: '80px', borderRadius: '50%',
            background: generateColor(user?.id || ''),
            color: 'white',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '30px', fontWeight: 700, flexShrink: 0,
            boxShadow: '0 4px 16px rgba(0,0,0,0.12)',
          }}>
            {getInitials(user?.firstName || '', user?.lastName || '')}
          </div>
          <div>
            <div style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '22px', fontWeight: 700, color: 'var(--text)', marginBottom: '4px' }}>
              {user?.firstName} {user?.lastName}
            </div>
            <div style={{ color: 'var(--text-muted)', fontSize: '14px', marginBottom: '8px' }}>{user?.email}</div>
            <span className={`badge ${user?.role === 'admin' ? 'badge-warning' : 'badge-success'}`} style={{ textTransform: 'capitalize' }}>{user?.role}</span>
          </div>
        </div>

        <form data-testid="profile-form" onSubmit={handleSave} noValidate>

          {/* Personal Information */}
          <div style={{
            background: 'var(--surface)',
            borderRadius: '18px',
            boxShadow: 'var(--shadow)',
            padding: '28px',
            marginBottom: '20px',
            border: '1px solid var(--border)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '22px' }}>
              <div style={{
                width: '36px', height: '36px', borderRadius: '10px',
                background: 'var(--accent-light)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--accent)',
                flexShrink: 0,
              }}>
                <User size={17} />
              </div>
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', fontWeight: 700, margin: 0, color: 'var(--text)' }}>
                Personal Information
              </h3>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
              {f('firstName', 'First Name', <User size={15} />, 'text', 'Alex')}
              {f('lastName', 'Last Name', <User size={15} />, 'text', 'Johnson')}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              {f('email', 'Email Address', <Mail size={15} />, 'email', 'alex@demo.com')}
              {f('phone', 'Phone Number', <Phone size={15} />, 'tel', '+1 (555) 867-5309')}
            </div>
          </div>

          {/* Address */}
          <div style={{
            background: 'var(--surface)',
            borderRadius: '18px',
            boxShadow: 'var(--shadow)',
            padding: '28px',
            marginBottom: '24px',
            border: '1px solid var(--border)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '22px' }}>
              <div style={{
                width: '36px', height: '36px', borderRadius: '10px',
                background: 'var(--accent-light)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--accent)',
                flexShrink: 0,
              }}>
                <MapPin size={17} />
              </div>
              <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', fontWeight: 700, margin: 0, color: 'var(--text)' }}>
                Address
              </h3>
            </div>
            <div style={{ marginBottom: '16px' }}>
              {f('address.street', 'Street Address', <MapPin size={15} />, 'text', '123 Oak Street')}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
              {f('address.city', 'City', <MapPin size={15} />, 'text', 'Chicago')}
              {f('address.state', 'State', <MapPin size={15} />, 'text', 'Illinois')}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              {f('address.zip', 'ZIP Code', <MapPin size={15} />, 'text', '60601')}
              <div>
                <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Country</label>
                <select data-testid="profile-address-country" className="input-field" value={form.address.country} onChange={e => setForm(f => ({ ...f, address: { ...f.address, country: e.target.value } }))}>
                  {['United States','Canada','United Kingdom','Australia','Mexico'].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button type="submit" data-testid="save-profile" className="btn-primary" disabled={mutation.isPending}>
              <Save size={16} />{mutation.isPending ? 'Saving…' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
