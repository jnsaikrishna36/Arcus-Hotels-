'use client';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/lib/stores/auth';
import { Navbar } from '@/components/layout/Navbar';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Booking } from '@/types';
import { BookOpen, User, Settings, Hotel, ArrowRight, Calendar } from 'lucide-react';

export default function DashboardPage() {
  const { user } = useAuthStore();
  const router = useRouter();

  const { data } = useQuery({
    queryKey: ['my-bookings', 'dashboard'],
    queryFn: () => api.get<any>('/api/bookings?page=1&limit=3'),
  });

  const recentBookings: Booking[] = data?.data || [];

  const cards = [
    { icon: <Hotel size={22} />, label: 'Search Stays', desc: 'Find your next stay', href: '/hotels/search', testid: 'dash-search' },
    { icon: <BookOpen size={22} />, label: 'My Bookings', desc: `${data?.total || 0} total booking${data?.total !== 1 ? 's' : ''}`, href: '/dashboard/bookings', testid: 'dash-bookings' },
    { icon: <User size={22} />, label: 'Profile', desc: 'Update your details', href: '/dashboard/profile', testid: 'dash-profile' },
    { icon: <Settings size={22} />, label: 'Settings', desc: 'Account preferences', href: '/dashboard/settings', testid: 'dash-settings' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />

      {/* Hero Banner */}
      <div style={{
        background: 'linear-gradient(180deg,#0d1b3e 0%,#22356b 34%,#4a5d97 60%,#a9806f 84%,#e7b98f 100%)',
        height: '172px',
        overflow: 'hidden',
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
      }}>
        <div style={{
          position: 'absolute', top: '50%', left: '60%', transform: 'translate(-50%,-50%)',
          width: '600px', height: '600px',
          background: 'radial-gradient(circle, rgba(0,178,189,0.18) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1, width: '100%' }}>
          <h1 style={{
            fontFamily: "'Bricolage Grotesque','Inter',sans-serif",
            fontSize: 'clamp(26px,3vw,34px)',
            fontWeight: 800,
            color: '#fff',
            margin: 0,
            marginBottom: '6px',
          }}>
            Welcome back, {user?.firstName}! 👋
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.72)', margin: 0, fontSize: '15px' }}>
            Here's a quick overview of your account
          </p>
        </div>
      </div>

      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 24px 60px' }} data-testid="dashboard">

        {/* Stat Strip */}
        <div style={{
          background: 'var(--surface)',
          borderRadius: '18px',
          boxShadow: 'var(--shadow)',
          padding: '24px 32px',
          marginTop: '28px',
          marginBottom: '32px',
          display: 'flex',
          alignItems: 'center',
          gap: '0',
        }}>
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '32px', fontWeight: 800, color: 'var(--text)' }}>{data?.total || 0}</div>
            <div style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '4px' }}>Total Bookings</div>
          </div>
          <div style={{ width: '1px', height: '48px', background: 'var(--border)' }} />
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '32px', fontWeight: 800, color: 'var(--text)' }}>
              {recentBookings.filter(b => b.status === 'confirmed').length}
            </div>
            <div style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '4px' }}>Confirmed</div>
          </div>
          <div style={{ width: '1px', height: '48px', background: 'var(--border)' }} />
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '32px', fontWeight: 800, color: 'var(--text)' }}>
              {recentBookings.filter(b => b.status === 'completed').length}
            </div>
            <div style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '4px' }}>Completed</div>
          </div>
        </div>

        {/* Quick Action Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: '16px', marginBottom: '36px' }}>
          {cards.map(c => (
            <button key={c.href} data-testid={c.testid} onClick={() => router.push(c.href)}
              style={{
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                borderRadius: '18px',
                padding: '24px',
                textAlign: 'left',
                cursor: 'pointer',
                transition: 'all 0.2s',
                fontFamily: "'Inter',sans-serif",
                boxShadow: 'var(--shadow)',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'var(--accent)';
                e.currentTarget.style.transform = 'translateY(-3px)';
                e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--border)';
                e.currentTarget.style.transform = 'none';
                e.currentTarget.style.boxShadow = 'var(--shadow)';
              }}>
              <div style={{
                width: '52px', height: '52px', borderRadius: '14px',
                background: 'var(--accent-light)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--accent)',
                marginBottom: '14px',
              }}>
                {c.icon}
              </div>
              <div style={{ fontWeight: 700, fontSize: '15px', marginBottom: '4px', color: 'var(--text)' }}>{c.label}</div>
              <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>{c.desc}</div>
            </button>
          ))}
        </div>

        {/* Recent Bookings */}
        {recentBookings.length > 0 && (
          <div style={{
            background: 'var(--surface)',
            borderRadius: '18px',
            boxShadow: 'var(--shadow)',
            padding: '28px',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '20px', fontWeight: 700, color: 'var(--text)', margin: 0 }}>
                Recent Bookings
              </h2>
              <button onClick={() => router.push('/dashboard/bookings')}
                style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', fontSize: '14px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px' }}>
                View all <ArrowRight size={14} />
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {recentBookings.map(b => (
                <div key={b.id} data-testid={`recent-booking-${b.id}`}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '14px',
                    padding: '14px',
                    background: 'var(--surface-warm)',
                    borderRadius: '12px',
                    border: '1px solid var(--border)',
                  }}>
                  <img src={b.hotel.images[0]} alt={b.hotel.name} style={{ width: '60px', height: '48px', objectFit: 'cover', borderRadius: '8px' }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: '14px', color: 'var(--text)' }}>{b.hotel.name}</div>
                    <div style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
                      <Calendar size={11} />{formatDate(b.checkIn)} – {formatDate(b.checkOut)}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <span className={`badge ${b.status === 'confirmed' ? 'badge-success' : b.status === 'cancelled' ? 'badge-error' : 'badge-neutral'}`} style={{ textTransform: 'capitalize' }}>{b.status}</span>
                    <div style={{ fontSize: '13px', fontWeight: 600, marginTop: '4px', color: 'var(--accent)' }}>{formatCurrency(b.totalPrice)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
