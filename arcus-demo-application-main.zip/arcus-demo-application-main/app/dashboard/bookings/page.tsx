'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Navbar } from '@/components/layout/Navbar';
import { api } from '@/lib/api';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Booking } from '@/types';
import { toast } from '@/components/ui/Toaster';
import { BookOpen, MapPin, Calendar, AlertCircle, X, Eye } from 'lucide-react';

function CancelModal({ booking, onClose, onConfirm, loading }: { booking: Booking; onClose: () => void; onConfirm: () => void; loading: boolean }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
      <div data-testid="cancel-modal" className="card" style={{ maxWidth: '440px', width: '100%', padding: '28px', borderRadius: '18px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
          <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '20px' }}>Cancel Booking</h2>
          <button data-testid="close-modal" onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}><X size={20} /></button>
        </div>
        <div style={{ display: 'flex', gap: '12px', background: 'var(--error-light)', borderRadius: '8px', padding: '12px', marginBottom: '20px' }}>
          <AlertCircle size={16} color="var(--error)" style={{ flexShrink: 0, marginTop: '1px' }} />
          <p style={{ fontSize: '14px', color: 'var(--error)' }}>
            Are you sure you want to cancel <strong>{booking.referenceNumber}</strong> at <strong>{booking.hotel.name}</strong>? This action cannot be undone. A full refund will be processed.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
          <button data-testid="cancel-modal-no" onClick={onClose} className="btn-secondary">Keep Booking</button>
          <button data-testid="cancel-modal-yes" onClick={onConfirm} disabled={loading}
            style={{ background: 'var(--error)', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '8px', cursor: loading ? 'not-allowed' : 'pointer', fontWeight: 600, opacity: loading ? 0.7 : 1 }}>
            {loading ? 'Cancelling…' : 'Yes, Cancel'}
          </button>
        </div>
      </div>
    </div>
  );
}

const STATUS_STYLES: Record<string, string> = {
  confirmed: 'badge-success',
  completed: 'badge-neutral',
  cancelled: 'badge-error',
  pending: 'badge-warning',
};

export default function BookingsPage() {
  const router = useRouter();
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [cancelTarget, setCancelTarget] = useState<Booking | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['my-bookings', page, statusFilter],
    queryFn: () => api.get<any>(`/api/bookings?page=${page}&limit=5`),
  });

  const cancelMutation = useMutation({
    mutationFn: (id: string) => api.put(`/api/bookings/${id}/cancel`),
    onSuccess: () => {
      toast.success('Booking cancelled', 'Your refund will be processed in 3–5 business days.');
      qc.invalidateQueries({ queryKey: ['my-bookings'] });
      setCancelTarget(null);
    },
    onError: (err: any) => toast.error('Cancellation failed', err.message),
  });

  const bookings: Booking[] = (data?.data || []).filter((b: Booking) => !statusFilter || b.status === statusFilter);
  const total = data?.total || 0;
  const totalPages = data?.totalPages || 1;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      {cancelTarget && (
        <CancelModal
          booking={cancelTarget}
          onClose={() => setCancelTarget(null)}
          onConfirm={() => cancelMutation.mutate(cancelTarget.id)}
          loading={cancelMutation.isPending}
        />
      )}

      {/* Hero Banner */}
      <div style={{
        background: 'linear-gradient(180deg,#0d1b3e 0%,#22356b 34%,#4a5d97 60%,#a9806f 84%,#e7b98f 100%)',
        height: '172px',
        overflow: 'hidden',
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
      }}>
        <div style={{
          position: 'absolute', top: '50%', left: '60%', transform: 'translate(-50%,-50%)',
          width: '600px', height: '600px',
          background: 'radial-gradient(circle, rgba(0,178,189,0.18) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          maxWidth: '900px', margin: '0 auto', padding: '0 24px',
          position: 'relative', zIndex: 1, width: '100%',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div>
            <h1 style={{
              fontFamily: "'Bricolage Grotesque','Inter',sans-serif",
              fontSize: 'clamp(26px,3vw,34px)',
              fontWeight: 800,
              color: '#fff',
              margin: 0,
              marginBottom: '6px',
            }}>
              My Bookings
            </h1>
            <p style={{ color: 'rgba(255,255,255,0.72)', margin: 0, fontSize: '15px' }}>
              {total} booking{total !== 1 ? 's' : ''} total
            </p>
          </div>
          <button
            data-testid="search-hotels-btn"
            onClick={() => router.push('/hotels/search')}
            style={{
              border: '1px solid rgba(255,255,255,0.5)',
              color: '#fff',
              background: 'rgba(255,255,255,0.1)',
              borderRadius: '999px',
              padding: '10px 22px',
              cursor: 'pointer',
              fontWeight: 600,
              fontSize: '14px',
              transition: 'background 0.15s',
              fontFamily: "'Inter',sans-serif",
            }}
            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.2)'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.1)'; }}
          >
            Book a Hotel
          </button>
        </div>
      </div>

      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '0 24px 60px' }} data-testid="bookings-page">

        {/* Status Filter */}
        <div style={{ display: 'flex', gap: '8px', margin: '28px 0 20px' }}>
          {[['', 'All'], ['confirmed', 'Confirmed'], ['completed', 'Completed'], ['cancelled', 'Cancelled']].map(([val, label]) => (
            <button key={val} data-testid={`status-filter-${val || 'all'}`} onClick={() => setStatusFilter(val)}
              style={{
                padding: '6px 16px',
                borderRadius: '999px',
                border: '1px solid',
                borderColor: statusFilter === val ? 'var(--accent)' : 'var(--border)',
                background: statusFilter === val ? 'var(--accent-light)' : 'transparent',
                color: statusFilter === val ? 'var(--accent-dark)' : 'var(--text-muted)',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: statusFilter === val ? 700 : 400,
                transition: 'all 0.15s',
              }}>
              {label}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {[1,2,3].map(i => <div key={i} className="skeleton" style={{ height: '120px', borderRadius: '18px' }} />)}
          </div>
        ) : bookings.length === 0 ? (
          <div data-testid="no-bookings" style={{ textAlign: 'center', padding: '60px 24px', color: 'var(--text-muted)' }}>
            <BookOpen size={40} style={{ opacity: 0.3, marginBottom: '16px' }} />
            <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '20px', color: 'var(--text)', marginBottom: '8px' }}>No bookings yet</h3>
            <p>Start by searching for a hotel.</p>
            <button onClick={() => router.push('/hotels/search')} className="btn-primary" style={{ marginTop: '20px', fontSize: '14px' }}>Find a Hotel</button>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {bookings.map(b => (
              <div key={b.id} data-testid={`booking-card-${b.id}`}
                style={{
                  background: 'var(--surface)',
                  borderRadius: '18px',
                  boxShadow: 'var(--shadow)',
                  padding: '20px',
                  transition: 'all 0.2s',
                  border: '1px solid var(--border)',
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-3px)';
                  (e.currentTarget as HTMLDivElement).style.boxShadow = 'var(--shadow-lg)';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLDivElement).style.transform = 'none';
                  (e.currentTarget as HTMLDivElement).style.boxShadow = 'var(--shadow)';
                }}
              >
                <div style={{ display: 'flex', gap: '16px' }}>
                  <img src={b.hotel.images[0]} alt={b.hotel.name} style={{ width: '100px', height: '80px', objectFit: 'cover', borderRadius: '10px', flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                      <div>
                        <h3 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '17px', fontWeight: 600, margin: 0 }}>{b.hotel.name}</h3>
                        <div style={{ color: 'var(--text-muted)', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '4px', marginTop: '3px' }}>
                          <MapPin size={11} />{b.hotel.city}
                        </div>
                      </div>
                      <span data-testid={`booking-status-${b.id}`} className={`badge ${STATUS_STYLES[b.status] || 'badge-neutral'}`} style={{ textTransform: 'capitalize', flexShrink: 0 }}>
                        {b.status}
                      </span>
                    </div>
                    <div style={{ display: 'flex', gap: '20px', fontSize: '13px', color: 'var(--text-muted)', marginBottom: '12px', flexWrap: 'wrap' }}>
                      <span data-testid={`booking-ref-${b.id}`} style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--accent)' }}>{b.referenceNumber}</span>
                      <span><Calendar size={12} style={{ display: 'inline', marginRight: '3px' }} />{formatDate(b.checkIn)} – {formatDate(b.checkOut)}</span>
                      <span>{b.nights} nights · {b.guests} guests</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontWeight: 700, fontSize: '16px', color: 'var(--accent)' }}>{formatCurrency(b.totalPrice)}</span>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button data-testid={`view-booking-${b.id}`} onClick={() => router.push(`/booking/confirmation/${b.id}`)}
                          style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 14px', border: '1px solid var(--border)', borderRadius: '999px', background: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: 500, color: 'var(--text)', transition: 'all 0.15s' }}
                          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)'; }}
                          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text)'; }}>
                          <Eye size={13} />View
                        </button>
                        {b.status === 'confirmed' && (
                          <button data-testid={`cancel-booking-${b.id}`} onClick={() => setCancelTarget(b)}
                            style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 14px', border: '1px solid var(--error)', borderRadius: '999px', background: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: 500, color: 'var(--error)', transition: 'all 0.15s' }}
                            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(220,38,38,0.06)'; }}
                            onMouseLeave={e => { e.currentTarget.style.background = 'none'; }}>
                            <X size={13} />Cancel
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {totalPages > 1 && (
          <div data-testid="bookings-pagination" style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '28px' }}>
            <button data-testid="prev-page" onClick={() => setPage(p => p - 1)} disabled={page === 1}
              style={{ padding: '8px 16px', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--surface)', cursor: page === 1 ? 'not-allowed' : 'pointer', opacity: page === 1 ? 0.4 : 1 }}>
              ← Prev
            </button>
            <span style={{ padding: '8px 16px', fontSize: '14px', color: 'var(--text-muted)' }}>Page {page} of {totalPages}</span>
            <button data-testid="next-page" onClick={() => setPage(p => p + 1)} disabled={page === totalPages}
              style={{ padding: '8px 16px', border: '1px solid var(--border)', borderRadius: '8px', background: 'var(--surface)', cursor: page === totalPages ? 'not-allowed' : 'pointer', opacity: page === totalPages ? 0.4 : 1 }}>
              Next →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
