'use client';
import { useState } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { toast } from '@/components/ui/Toaster';
import { api } from '@/lib/api';
import { Eye, EyeOff, Bell, Lock, Globe, Trash2 } from 'lucide-react';

export default function SettingsPage() {
  const [pwForm, setPwForm] = useState({ current: '', newPw: '', confirm: '' });
  const [pwErrors, setPwErrors] = useState<Record<string, string>>({});
  const [showPw, setShowPw] = useState(false);
  const [pwLoading, setPwLoading] = useState(false);

  const [notifs, setNotifs] = useState({
    bookingConfirmation: true,
    reminders: true,
    promotions: false,
    newsletter: false,
  });

  const [prefs, setPrefs] = useState({ currency: 'USD', language: 'en', theme: 'light' });

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!pwForm.current) errs.current = 'Current password required';
    if (!pwForm.newPw || pwForm.newPw.length < 8) errs.newPw = 'Min 8 characters';
    if (pwForm.newPw !== pwForm.confirm) errs.confirm = 'Passwords do not match';
    setPwErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setPwLoading(true);
    await new Promise(r => setTimeout(r, 800)); // Simulated delay
    toast.success('Password changed', 'Your new password is active.');
    setPwForm({ current: '', newPw: '', confirm: '' });
    setPwLoading(false);
  };

  const handleSaveNotifs = () => {
    toast.success('Preferences saved', 'Your notification settings have been updated.');
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />

      {/* Hero Banner */}
      <div style={{
        background: 'linear-gradient(180deg,#0d1b3e 0%,#22356b 34%,#4a5d97 60%,#a9806f 84%,#e7b98f 100%)',
        height: '172px',
        overflow: 'hidden',
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
      }}>
        <div style={{
          position: 'absolute', top: '50%', left: '60%', transform: 'translate(-50%,-50%)',
          width: '600px', height: '600px',
          background: 'radial-gradient(circle, rgba(0,178,189,0.18) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{ maxWidth: '700px', margin: '0 auto', padding: '0 24px', position: 'relative', zIndex: 1, width: '100%' }}>
          <h1 style={{
            fontFamily: "'Bricolage Grotesque','Inter',sans-serif",
            fontSize: 'clamp(26px,3vw,34px)',
            fontWeight: 800,
            color: '#fff',
            margin: 0,
            marginBottom: '6px',
          }}>
            Account Settings
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.72)', margin: 0, fontSize: '15px' }}>
            Manage your security, notifications and preferences
          </p>
        </div>
      </div>

      <div style={{ maxWidth: '700px', margin: '0 auto', padding: '0 24px 60px' }} data-testid="settings-page">

        {/* Change Password */}
        <div style={{
          background: 'var(--surface)',
          borderRadius: '18px',
          boxShadow: 'var(--shadow)',
          padding: '28px',
          marginTop: '28px',
          marginBottom: '20px',
          border: '1px solid var(--border)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '22px' }}>
            <div style={{
              width: '38px', height: '38px', borderRadius: '11px',
              background: 'var(--accent-light)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--accent)', flexShrink: 0,
            }}>
              <Lock size={18} />
            </div>
            <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', fontWeight: 700, margin: 0, color: 'var(--text)' }}>
              Change Password
            </h2>
          </div>
          <form data-testid="change-password-form" onSubmit={handleChangePassword} noValidate>
            {[
              { key: 'current', label: 'Current Password', testid: 'current-password' },
              { key: 'newPw', label: 'New Password', testid: 'new-password' },
              { key: 'confirm', label: 'Confirm New Password', testid: 'confirm-password' },
            ].map(field => (
              <div key={field.key} style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>{field.label}</label>
                <div style={{ position: 'relative' }}>
                  <input
                    data-testid={field.testid}
                    type={showPw ? 'text' : 'password'}
                    className={`input-field ${pwErrors[field.key] ? 'error' : ''}`}
                    style={{ paddingRight: '40px' }}
                    value={(pwForm as any)[field.key]}
                    onChange={e => { setPwForm(f => ({ ...f, [field.key]: e.target.value })); setPwErrors(er => ({ ...er, [field.key]: '' })); }}
                  />
                  {field.key === 'current' && (
                    <button type="button" data-testid="toggle-pw-visibility" onClick={() => setShowPw(!showPw)}
                      style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
                      {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  )}
                </div>
                {pwErrors[field.key] && <p data-testid={`${field.testid}-error`} style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{pwErrors[field.key]}</p>}
              </div>
            ))}
            <button type="submit" data-testid="save-password" className="btn-primary" disabled={pwLoading}>
              {pwLoading ? 'Updating…' : 'Update Password'}
            </button>
          </form>
        </div>

        {/* Notifications */}
        <div style={{
          background: 'var(--surface)',
          borderRadius: '18px',
          boxShadow: 'var(--shadow)',
          padding: '28px',
          marginBottom: '20px',
          border: '1px solid var(--border)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '22px' }}>
            <div style={{
              width: '38px', height: '38px', borderRadius: '11px',
              background: 'var(--accent-light)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--accent)', flexShrink: 0,
            }}>
              <Bell size={18} />
            </div>
            <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', fontWeight: 700, margin: 0, color: 'var(--text)' }}>
              Notifications
            </h2>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            {[
              { key: 'bookingConfirmation', label: 'Booking confirmations', desc: 'Get notified when a booking is confirmed or cancelled' },
              { key: 'reminders', label: 'Stay reminders', desc: '48 hours before your check-in' },
              { key: 'promotions', label: 'Special offers', desc: 'Deals and promotions tailored to your preferences' },
              { key: 'newsletter', label: 'Newsletter', desc: 'Monthly travel inspiration and guides' },
            ].map((n, idx, arr) => (
              <label key={n.key} data-testid={`notif-${n.key}`}
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  cursor: 'pointer',
                  padding: '14px 16px',
                  borderRadius: '12px',
                  background: (notifs as any)[n.key] ? 'var(--accent-light)' : 'var(--surface-warm)',
                  border: `1px solid ${(notifs as any)[n.key] ? 'rgba(0,178,189,0.25)' : 'var(--border)'}`,
                  marginBottom: idx < arr.length - 1 ? '8px' : '0',
                  transition: 'all 0.15s',
                }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '14px', color: 'var(--text)' }}>{n.label}</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '2px' }}>{n.desc}</div>
                </div>
                <input type="checkbox" checked={(notifs as any)[n.key]} onChange={e => setNotifs(ns => ({ ...ns, [n.key]: e.target.checked }))}
                  style={{ width: '18px', height: '18px', accentColor: 'var(--accent)', cursor: 'pointer', flexShrink: 0, marginLeft: '16px' }} />
              </label>
            ))}
          </div>
          <button data-testid="save-notifications" onClick={handleSaveNotifs} className="btn-primary" style={{ marginTop: '20px', fontSize: '14px' }}>
            Save Preferences
          </button>
        </div>

        {/* Preferences */}
        <div style={{
          background: 'var(--surface)',
          borderRadius: '18px',
          boxShadow: 'var(--shadow)',
          padding: '28px',
          marginBottom: '20px',
          border: '1px solid var(--border)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '22px' }}>
            <div style={{
              width: '38px', height: '38px', borderRadius: '11px',
              background: 'var(--accent-light)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--accent)', flexShrink: 0,
            }}>
              <Globe size={18} />
            </div>
            <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', fontWeight: 700, margin: 0, color: 'var(--text)' }}>
              Preferences
            </h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
            {[
              { key: 'currency', label: 'Currency', opts: ['USD','EUR','GBP','CAD','AUD'] },
              { key: 'language', label: 'Language', opts: [['en','English'],['es','Spanish'],['fr','French'],['de','German']] },
              { key: 'theme', label: 'Theme', opts: ['light','dark','system'] },
            ].map(p => (
              <div key={p.key}>
                <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px', textTransform: 'capitalize' }}>{p.label}</label>
                <select data-testid={`pref-${p.key}`} className="input-field" value={(prefs as any)[p.key]} onChange={e => setPrefs(pr => ({ ...pr, [p.key]: e.target.value }))}>
                  {p.opts.map(o => Array.isArray(o) ? <option key={o[0]} value={o[0]}>{o[1]}</option> : <option key={o} value={o} style={{ textTransform: 'capitalize' }}>{o}</option>)}
                </select>
              </div>
            ))}
          </div>
          <button data-testid="save-preferences" onClick={() => toast.success('Preferences saved')} className="btn-primary" style={{ marginTop: '20px', fontSize: '14px' }}>
            Save Preferences
          </button>
        </div>

        {/* Danger Zone */}
        <div style={{
          background: 'var(--surface)',
          borderRadius: '18px',
          padding: '28px',
          border: '1px solid var(--error)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
            <div style={{
              width: '38px', height: '38px', borderRadius: '11px',
              background: 'rgba(220,38,38,0.08)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--error)', flexShrink: 0,
            }}>
              <Trash2 size={18} />
            </div>
            <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '18px', fontWeight: 700, margin: 0, color: 'var(--error)' }}>
              Danger Zone
            </h2>
          </div>
          <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '16px' }}>Permanently delete your account and all associated data. This cannot be undone.</p>
          <button data-testid="delete-account" onClick={() => toast.error('Action blocked', 'This is a demo application — account deletion is disabled.')}
            style={{ background: 'none', border: '1px solid var(--error)', color: 'var(--error)', padding: '10px 20px', borderRadius: '999px', cursor: 'pointer', fontWeight: 600, fontSize: '14px', transition: 'background 0.15s' }}
            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(220,38,38,0.06)'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'none'; }}>
            Delete Account
          </button>
        </div>
      </div>
    </div>
  );
}
