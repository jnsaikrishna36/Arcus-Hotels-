'use client';
import { useEffect, useRef, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuthStore } from '@/lib/stores/auth';
import { api } from '@/lib/api';
import { toast } from '@/components/ui/Toaster';
import { SSOProvider } from '@/types';
import { AppIcon } from '@/components/brand/AppIcon';

const PROVIDER_LABELS: Record<SSOProvider, string> = {
  google: 'Google',
  microsoft: 'Microsoft',
  github: 'GitHub',
};

export default function SSOCallbackPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { setAuth } = useAuthStore();
  const [status, setStatus] = useState<'loading' | 'error'>('loading');
  const [errorMsg, setErrorMsg] = useState('');
  const called = useRef(false);

  useEffect(() => {
    if (called.current) return;
    called.current = true;

    const provider = searchParams.get('provider') as SSOProvider | null;
    const code = searchParams.get('code');
    const error = searchParams.get('error');

    if (error) {
      setErrorMsg(`Authorization denied: ${error}`);
      setStatus('error');
      return;
    }

    if (!provider || !code) {
      setErrorMsg('Missing SSO parameters. Please try signing in again.');
      setStatus('error');
      return;
    }

    const valid: SSOProvider[] = ['google', 'microsoft', 'github'];
    if (!valid.includes(provider)) {
      setErrorMsg('Unknown SSO provider.');
      setStatus('error');
      return;
    }

    api
      .post<{ success: boolean; message: string; data: { user: any; token: string } }>(
        '/api/auth/sso/callback',
        { provider, code }
      )
      .then(res => {
        setAuth(res.data.user, res.data.token);
        const label = PROVIDER_LABELS[provider];
        toast.success(`Signed in with ${label}`, `Welcome, ${res.data.user.firstName}!`);
        router.replace(res.data.user.role === 'admin' ? '/admin/dashboard' : '/dashboard');
      })
      .catch(err => {
        setErrorMsg(err.message || 'SSO login failed. Please try again.');
        setStatus('error');
      });
  }, [searchParams, setAuth, router]);

  return (
    <div
      data-testid="sso-callback"
      style={{
        minHeight: '100vh',
        background: 'var(--bg)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '24px',
      }}
    >
      <div style={{ width: '100%', maxWidth: '420px' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '32px' }}>
          <a href="/" style={{ display: 'flex', alignItems: 'center', gap: '11px', textDecoration: 'none' }}>
            <AppIcon size={42} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
              <span style={{ fontSize: '20px', color: 'var(--ink)', fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1, fontFamily: "'Bricolage Grotesque','Inter',sans-serif", whiteSpace: 'nowrap' }}>Arcus Go</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '10px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', lineHeight: 1 }}>
                Powered by
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/testsigma-logo.svg" alt="Testsigma" style={{ height: '11px', display: 'block', opacity: 0.75 }} />
              </span>
            </div>
          </a>
        </div>

        <div className="card" style={{ padding: '40px', textAlign: 'center' }}>
          {status === 'loading' ? (
            <>
              <div
                data-testid="sso-loading"
                style={{
                  width: '48px',
                  height: '48px',
                  border: '3px solid var(--border)',
                  borderTopColor: 'var(--accent)',
                  borderRadius: '50%',
                  animation: 'spin 0.8s linear infinite',
                  margin: '0 auto 20px',
                }}
              />
              <p style={{ fontWeight: 600, marginBottom: '8px' }}>Completing sign-in…</p>
              <p style={{ fontSize: '14px', color: 'var(--text-muted)' }}>
                Verifying your identity with{' '}
                {PROVIDER_LABELS[(searchParams.get('provider') as SSOProvider) ?? 'google'] ?? 'your provider'}
              </p>
            </>
          ) : (
            <>
              <div
                style={{
                  width: '48px',
                  height: '48px',
                  background: 'var(--error-light)',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 20px',
                  fontSize: '22px',
                }}
              >
                ✕
              </div>
              <p data-testid="sso-error" style={{ fontWeight: 600, color: 'var(--error)', marginBottom: '8px' }}>
                Sign-in failed
              </p>
              <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '24px' }}>{errorMsg}</p>
              <button
                data-testid="sso-retry"
                className="btn-primary"
                onClick={() => router.replace('/auth/login')}
                style={{ width: '100%', justifyContent: 'center' }}
              >
                Back to Login
              </button>
            </>
          )}
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
