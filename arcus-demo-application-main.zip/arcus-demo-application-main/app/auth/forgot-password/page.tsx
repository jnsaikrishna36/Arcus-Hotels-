'use client';
import { useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';
import { AppIcon } from '@/components/brand/AppIcon';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) { setError('Email is required'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setError('Enter a valid email'); return; }
    setLoading(true);
    try {
      await api.post('/api/auth/forgot-password', { email });
      setSent(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
      <div style={{ width: '100%', maxWidth: '420px' }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', textDecoration: 'none', marginBottom: '32px' }}>
          <AppIcon size={38} />
          <span style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '22px', color: 'var(--ink)', fontWeight: 800, letterSpacing: '-0.03em' }}>Arcus Go</span>
        </Link>
        <div className="card" style={{ padding: '36px' }}>
          {sent ? (
            <div data-testid="reset-success" style={{ textAlign: 'center' }}>
              <CheckCircle size={48} style={{ color: 'var(--success)', margin: '0 auto 16px' }} />
              <h2 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '22px', marginBottom: '8px' }}>Check your email</h2>
              <p style={{ color: 'var(--text-muted)', fontSize: '14px', lineHeight: 1.6, marginBottom: '24px' }}>
                We sent a password reset link to <strong>{email}</strong>. Check your inbox and follow the instructions.
              </p>
              <Link href="/auth/login" style={{ color: 'var(--accent)', fontWeight: 600, textDecoration: 'none', fontSize: '14px' }}>Back to login</Link>
            </div>
          ) : (
            <>
              <Link href="/auth/login" data-testid="back-to-login" style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', color: 'var(--text-muted)', textDecoration: 'none', fontSize: '13px', marginBottom: '20px' }}>
                <ArrowLeft size={14} />Back to login
              </Link>
              <h1 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '24px', marginBottom: '6px' }}>Reset password</h1>
              <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginBottom: '24px', lineHeight: 1.6 }}>Enter your email and we'll send you a reset link.</p>
              <form data-testid="forgot-password-form" onSubmit={handleSubmit} noValidate>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '6px' }}>Email Address</label>
                  <div style={{ position: 'relative' }}>
                    <Mail size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                    <input data-testid="forgot-email" type="email" className={`input-field ${error ? 'error' : ''}`} style={{ paddingLeft: '40px' }} placeholder="your@email.com" value={email} onChange={e => { setEmail(e.target.value); setError(''); }} />
                  </div>
                  {error && <p data-testid="email-error" style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{error}</p>}
                </div>
                <button type="submit" data-testid="send-reset-btn" className="btn-primary" disabled={loading} style={{ width: '100%', justifyContent: 'center' }}>
                  {loading ? 'Sending…' : 'Send Reset Link'}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
