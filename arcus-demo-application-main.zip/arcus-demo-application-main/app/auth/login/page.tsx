'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuthStore } from '@/lib/stores/auth';
import { api } from '@/lib/api';
import { toast } from '@/components/ui/Toaster';
import { Eye, EyeOff, Mail, Lock, ArrowRight, ShieldCheck, Zap, RefreshCw } from 'lucide-react';
import { SSOProvider } from '@/types';
import SSOFlow from '@/components/auth/SSOFlow';
import { TravelDecorations } from '@/components/auth/TravelDecorations';
import { AppIcon } from '@/components/brand/AppIcon';

interface LoginResponse { data: { user: any; token: string }; message: string; }

const SSO_PROVIDERS: { provider: SSOProvider; label: string; Logo: () => React.ReactElement; bg: string; border: string; color: string }[] = [
  {
    provider: 'google', label: 'Google', bg: '#fff', border: '#dadce0', color: '#3c4043',
    Logo: () => (
      <svg width="18" height="18" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
    ),
  },
  {
    provider: 'microsoft', label: 'Microsoft', bg: '#fff', border: '#8a8a8a', color: '#1b1b1b',
    Logo: () => (
      <svg width="17" height="17" viewBox="0 0 22 22"><rect x="0" y="0" width="10.5" height="10.5" fill="#F25022"/><rect x="11.5" y="0" width="10.5" height="10.5" fill="#7FBA00"/><rect x="0" y="11.5" width="10.5" height="10.5" fill="#00A4EF"/><rect x="11.5" y="11.5" width="10.5" height="10.5" fill="#FFB900"/></svg>
    ),
  },
  {
    provider: 'github', label: 'GitHub', bg: '#24292e', border: '#24292e', color: '#fff',
    Logo: () => (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
    ),
  },
];

const FEATURES = [
  { icon: <Zap size={17} />, text: 'Instant booking confirmation' },
  { icon: <RefreshCw size={17} />, text: 'Free cancellation on most stays' },
  { icon: <ShieldCheck size={17} />, text: 'Verified hotels & real reviews' },
];

function ArcusLogo({ dark }: { dark?: boolean }) {
  const txt = dark ? '#ffffff' : 'var(--ink)';
  const sub = dark ? 'rgba(255,255,255,0.62)' : 'var(--text-muted)';
  const logoSrc = dark ? '/testsigma-logo-white.svg' : '/testsigma-logo.svg';
  return (
    <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '11px', textDecoration: 'none' }}>
      <AppIcon size={42} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
        <span style={{ fontSize: '20px', color: txt, fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1, fontFamily: "'Bricolage Grotesque','Inter',sans-serif", whiteSpace: 'nowrap' }}>Arcus Go</span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '10px', fontWeight: 600, color: sub, textTransform: 'uppercase', letterSpacing: '0.06em', lineHeight: 1 }}>
          Powered by
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={logoSrc} alt="Testsigma" style={{ height: '11px', display: 'block' }} />
        </span>
      </div>
    </Link>
  );
}

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { setAuth } = useAuthStore();
  const [form, setForm] = useState({ email: '', password: '', rememberMe: false });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeSSO, setActiveSSO] = useState<SSOProvider | null>(null);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.email) e.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email';
    if (!form.password) e.password = 'Password is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await api.post<LoginResponse>('/api/auth/login', form);
      setAuth(res.data.user, res.data.token);
      toast.success('Welcome back!', `Logged in as ${res.data.user.firstName}`);
      const callbackUrl = searchParams.get('callbackUrl');
      const redirectTo = callbackUrl && callbackUrl.startsWith('/') ? callbackUrl : (res.data.user.role === 'admin' ? '/admin/dashboard' : '/dashboard');
      router.push(redirectTo);
    } catch (err: any) {
      toast.error('Login failed', err.message);
      setErrors({ general: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div style={{ minHeight: '100vh', display: 'flex', background: 'var(--bg)' }}>

        {/* ── Left panel ──────────────────────────────────────────────── */}
        <div className="auth-panel-left" style={{
          flex: '0 0 44%',
          background: 'linear-gradient(160deg,#0d1b3e 0%,#22356b 38%,#4a5d97 68%,#a9806f 88%,#e7b98f 100%)',
          display: 'flex', flexDirection: 'column',
          padding: '48px 44px',
          position: 'relative', overflow: 'hidden',
        }}>
          {/* decorative glow */}
          <div style={{ position: 'absolute', top: '80px', left: '50%', transform: 'translateX(-50%)', width: '340px', height: '340px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,220,170,0.22), transparent 68%)', pointerEvents: 'none' }} />
          <TravelDecorations />

          <ArcusLogo dark />

          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', position: 'relative', zIndex: 1 }}>
            <h2 style={{ fontSize: 'clamp(26px,2.8vw,34px)', color: '#fff', fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontWeight: 800, lineHeight: 1.1, marginBottom: '16px', letterSpacing: '-0.02em' }}>
              Your perfect stay,<br />instantly booked.
            </h2>
            <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: '15px', lineHeight: 1.65, marginBottom: '36px', maxWidth: '320px' }}>
              Sign in to access your bookings, exclusive member rates, and 24×7 support.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {FEATURES.map(f => (
                <div key={f.text} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <span style={{ width: '34px', height: '34px', borderRadius: '10px', background: 'rgba(255,255,255,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#5fe0e6', flexShrink: 0 }}>{f.icon}</span>
                  <span style={{ color: 'rgba(255,255,255,0.88)', fontSize: '14px', fontWeight: 500 }}>{f.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Testimonial */}
          <div style={{ position: 'relative', zIndex: 1, background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.16)', borderRadius: '16px', padding: '20px 22px' }}>
            <p style={{ color: 'rgba(255,255,255,0.9)', fontSize: '13.5px', lineHeight: 1.6, marginBottom: '12px', fontStyle: 'italic' }}>
              "Booked in under a minute and the airport transfer was waiting when we landed. Genuinely flawless."
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ width: '34px', height: '34px', borderRadius: '50%', background: 'linear-gradient(140deg,var(--accent),#007e86)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '13px', flexShrink: 0 }}>M</span>
              <div>
                <div style={{ color: '#fff', fontWeight: 600, fontSize: '13px' }}>Maya R.</div>
                <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: '12px' }}>Stayed in Miami</div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Right panel ─────────────────────────────────────────────── */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 24px', overflowY: 'auto' }}>
          {/* Mobile-only logo */}
          <div className="auth-mobile-logo" style={{ display: 'none', marginBottom: '32px' }}>
            <ArcusLogo />
          </div>

          <div style={{ width: '100%', maxWidth: '420px' }}>
            <h1 style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '28px', fontWeight: 800, marginBottom: '6px', letterSpacing: '-0.02em' }}>Welcome back</h1>
            <p style={{ color: 'var(--text-muted)', fontSize: '14.5px', marginBottom: '32px' }}>Sign in to your account to continue</p>

            {errors.general && (
              <div data-testid="error-message" style={{ background: 'var(--error-light)', border: '1px solid var(--error)', borderRadius: '10px', padding: '12px 16px', color: 'var(--error)', fontSize: '14px', marginBottom: '20px' }}>
                {errors.general}
              </div>
            )}

            <form data-testid="login-form" onSubmit={handleSubmit} noValidate>
              <div style={{ marginBottom: '18px' }}>
                <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '7px', color: 'var(--text)' }}>Email Address</label>
                <div style={{ position: 'relative' }}>
                  <Mail size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                  <input
                    data-testid="login-email"
                    type="email"
                    className={`input-field ${errors.email ? 'error' : ''}`}
                    style={{ paddingLeft: '42px' }}
                    placeholder="alex@demo.com"
                    value={form.email}
                    onChange={e => { setForm(f => ({ ...f, email: e.target.value })); setErrors(er => ({ ...er, email: '', general: '' })); }}
                    autoComplete="email"
                  />
                </div>
                {errors.email && <p data-testid="email-error" style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.email}</p>}
              </div>

              <div style={{ marginBottom: '18px' }}>
                <label style={{ display: 'block', fontWeight: 600, fontSize: '13px', marginBottom: '7px', color: 'var(--text)' }}>Password</label>
                <div style={{ position: 'relative' }}>
                  <Lock size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                  <input
                    data-testid="login-password"
                    type={showPw ? 'text' : 'password'}
                    className={`input-field ${errors.password ? 'error' : ''}`}
                    style={{ paddingLeft: '42px', paddingRight: '42px' }}
                    placeholder="Your password"
                    value={form.password}
                    onChange={e => { setForm(f => ({ ...f, password: e.target.value })); setErrors(er => ({ ...er, password: '', general: '' })); }}
                    autoComplete="current-password"
                  />
                  <button type="button" data-testid="toggle-password" onClick={() => setShowPw(!showPw)} style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 0 }}>
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {errors.password && <p data-testid="password-error" style={{ color: 'var(--error)', fontSize: '12px', marginTop: '4px' }}>{errors.password}</p>}
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '26px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px', cursor: 'pointer' }}>
                  <input data-testid="remember-me" type="checkbox" checked={form.rememberMe} onChange={e => setForm(f => ({ ...f, rememberMe: e.target.checked }))} style={{ accentColor: 'var(--accent)', width: '15px', height: '15px' }} />
                  Remember me
                </label>
                <Link href="/auth/forgot-password" data-testid="forgot-password-link" style={{ fontSize: '14px', color: 'var(--accent)', textDecoration: 'none', fontWeight: 600 }}>
                  Forgot password?
                </Link>
              </div>

              <button type="submit" data-testid="login-submit" className="btn-primary" disabled={loading} style={{ width: '100%', justifyContent: 'center', height: '48px', fontSize: '15px' }}>
                {loading ? 'Signing in…' : <><ArrowRight size={16} />Sign In</>}
              </button>
            </form>

            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', margin: '24px 0' }}>
              <div style={{ flex: 1, height: '1px', background: 'var(--border)' }} />
              <span style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 500 }}>or continue with</span>
              <div style={{ flex: 1, height: '1px', background: 'var(--border)' }} />
            </div>

            <div data-testid="sso-buttons" style={{ display: 'flex', gap: '10px' }}>
              {SSO_PROVIDERS.map(({ provider, label, Logo, bg, border, color }) => (
                <button
                  key={provider}
                  data-testid={`sso-${provider}`}
                  type="button"
                  onClick={() => setActiveSSO(provider)}
                  style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px', padding: '10px 8px', background: bg, color, border: `1px solid ${border}`, borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 600, transition: 'filter 0.15s, transform 0.15s' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.filter = 'brightness(0.95)'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.filter = 'none'; (e.currentTarget as HTMLButtonElement).style.transform = 'none'; }}
                >
                  <Logo />
                  {label}
                </button>
              ))}
            </div>

            <div style={{ textAlign: 'center', marginTop: '28px', fontSize: '14px', color: 'var(--text-muted)' }}>
              Don't have an account?{' '}
              <Link href="/auth/register" data-testid="register-link" style={{ color: 'var(--accent)', fontWeight: 700, textDecoration: 'none' }}>Create one</Link>
            </div>

            {/* Test credentials */}
            <div style={{ marginTop: '20px', padding: '16px', background: 'var(--surface-alt)', borderRadius: '12px', border: '1px solid var(--border)' }}>
              <p style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: '8px' }}>Test Credentials</p>
              {[
                { label: 'User', email: 'alex@demo.com', pw: 'Demo@1234' },
                { label: 'Admin', email: 'admin@demo.com', pw: 'Admin@1234' },
              ].map(c => (
                <button key={c.label} data-testid={`demo-${c.label.toLowerCase()}`}
                  onClick={() => setForm({ email: c.email, password: c.pw, rememberMe: false })}
                  style={{ display: 'block', width: '100%', textAlign: 'left', background: 'none', border: 'none', padding: '4px 0', cursor: 'pointer', fontSize: '13px', color: 'var(--text)' }}>
                  <strong>{c.label}:</strong> {c.email} / {c.pw}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {activeSSO && <SSOFlow provider={activeSSO} onClose={() => setActiveSSO(null)} callbackUrl={searchParams.get('callbackUrl') ?? undefined} />}
    </>
  );
}
