'use client';
import { create } from 'zustand';
import { useEffect } from 'react';
import { CheckCircle, XCircle, AlertCircle, X } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info' | 'warning';
interface Toast { id: string; type: ToastType; title: string; message?: string; }

interface ToastStore {
  toasts: Toast[];
  add: (toast: Omit<Toast, 'id'>) => void;
  remove: (id: string) => void;
}

export const useToastStore = create<ToastStore>((set) => ({
  toasts: [],
  add: (toast) => {
    const id = Math.random().toString(36).slice(2);
    set((s) => ({ toasts: [...s.toasts, { ...toast, id }] }));
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), 4000);
  },
  remove: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}));

export const toast = {
  success: (title: string, message?: string) => useToastStore.getState().add({ type: 'success', title, message }),
  error: (title: string, message?: string) => useToastStore.getState().add({ type: 'error', title, message }),
  info: (title: string, message?: string) => useToastStore.getState().add({ type: 'info', title, message }),
  warning: (title: string, message?: string) => useToastStore.getState().add({ type: 'warning', title, message }),
};

const icons = {
  success: <CheckCircle size={18} style={{ color: 'var(--success)' }} />,
  error: <XCircle size={18} style={{ color: 'var(--error)' }} />,
  info: <AlertCircle size={18} style={{ color: 'var(--accent)' }} />,
  warning: <AlertCircle size={18} style={{ color: 'var(--warning)' }} />,
};

function ToastItem({ toast, onRemove }: { toast: Toast; onRemove: () => void }) {
  return (
    <div
      data-testid={`toast-${toast.type}`}
      style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: '10px',
        padding: '14px 16px',
        boxShadow: 'var(--shadow-lg)',
        display: 'flex',
        gap: '12px',
        alignItems: 'flex-start',
        minWidth: '300px',
        maxWidth: '400px',
        animation: 'fadeIn 0.25s ease',
      }}
    >
      <div style={{ marginTop: '1px' }}>{icons[toast.type]}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: '14px', color: 'var(--text)' }}>{toast.title}</div>
        {toast.message && <div style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '2px' }}>{toast.message}</div>}
      </div>
      <button onClick={onRemove} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '2px' }}>
        <X size={14} />
      </button>
    </div>
  );
}

export function Toaster() {
  const { toasts, remove } = useToastStore();
  return (
    <div style={{ position: 'fixed', top: '20px', right: '20px', zIndex: 9999, display: 'flex', flexDirection: 'column', gap: '8px' }}>
      {toasts.map((t) => <ToastItem key={t.id} toast={t} onRemove={() => remove(t.id)} />)}
    </div>
  );
}
