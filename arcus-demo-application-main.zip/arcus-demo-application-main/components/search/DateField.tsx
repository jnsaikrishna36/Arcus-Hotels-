'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import {
  format,
  parseISO,
  startOfMonth,
  startOfDay,
  getDay,
  getDaysInMonth,
  isBefore,
  isSameDay,
  addMonths,
  differenceInCalendarDays,
} from 'date-fns';

const DOW = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const ISO = (d: Date) => format(d, 'yyyy-MM-dd');

export interface DateFieldProps {
  value: string;
  onChange: (value: string) => void;
  min?: string;
  rangeStart?: string;
  rangeEnd?: string;
  role?: 'check-in' | 'check-out';
  testId?: string;
  align?: 'left' | 'right';
}

export function DateField({
  value,
  onChange,
  min,
  rangeStart,
  rangeEnd,
  role = 'check-in',
  testId,
  align = 'left',
}: DateFieldProps) {
  const ref = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const popRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0, right: 0, width: 0, maxHeight: 400 });

  const selected = value ? parseISO(value) : null;
  const minDate = min ? startOfDay(parseISO(min)) : null;
  const today = startOfDay(new Date());

  const [view, setView] = useState<Date>(startOfMonth(selected ?? today));

  useEffect(() => {
    if (open) setView(startOfMonth(selected ?? today));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  useEffect(() => {
    if (!open) return;

    if (triggerRef.current) {
      const r = triggerRef.current.getBoundingClientRect();
      const availH = window.innerHeight - r.bottom - 8 - 16;
      setPos({ top: r.bottom + 8, left: r.left, right: window.innerWidth - r.right, width: r.width, maxHeight: Math.max(120, Math.min(400, availH)) });
    }

    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    const onScroll = (e: Event) => {
      if (popRef.current && popRef.current.contains(e.target as Node)) return;
      setOpen(false);
    };

    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    window.addEventListener('scroll', onScroll, { passive: true, capture: true });
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('scroll', onScroll, true);
    };
  }, [open]);

  const rs = rangeStart ? startOfDay(parseISO(rangeStart)) : null;
  const re = rangeEnd ? startOfDay(parseISO(rangeEnd)) : null;

  const cells = useMemo(() => {
    const pad = getDay(startOfMonth(view));
    const total = getDaysInMonth(view);
    const arr: (Date | null)[] = [];
    for (let i = 0; i < pad; i++) arr.push(null);
    for (let d = 1; d <= total; d++) arr.push(new Date(view.getFullYear(), view.getMonth(), d));
    return arr;
  }, [view]);

  const limitMonth = startOfMonth(minDate ?? today);
  const atMin = view.getTime() <= limitMonth.getTime();
  const nights = rs && re ? differenceInCalendarDays(re, rs) : 0;

  const pick = (d: Date) => { onChange(ISO(d)); setOpen(false); };

  const dayClass = (d: Date) => {
    const cls = ['cal-day'];
    const disabled = minDate ? isBefore(d, minDate) : false;
    if (disabled) cls.push('disabled');
    if (isSameDay(d, today)) cls.push('today');
    const isStart = rs && isSameDay(d, rs);
    const isEnd = re && isSameDay(d, re);
    if (rs && re && isBefore(rs, d) && isBefore(d, re)) cls.push('range');
    if (isStart && re) cls.push('range-start');
    if (isEnd && rs) cls.push('range-end');
    if (isStart || isEnd || (selected && isSameDay(d, selected))) cls.push('sel');
    return cls.join(' ');
  };

  const triggerLabel = selected ? format(selected, 'd MMM yyyy') : 'Add date';

  return (
    <div className="sf" ref={ref} data-open={open}>
      <button
        ref={triggerRef}
        type="button"
        className="sf-trigger"
        data-testid={testId}
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        onKeyDown={(e) => {
          if (!open && ['Enter', ' ', 'ArrowDown'].includes(e.key)) { e.preventDefault(); setOpen(true); }
        }}
      >
        <span className={selected ? '' : 'sf-placeholder'}>{triggerLabel}</span>
        <CalendarIcon size={16} className="sf-leading-icon" />
      </button>

      {open && (
        <div
          ref={popRef}
          className={`sf-pop cal${align === 'right' ? ' sf-pop-right' : ''}`}
          role="dialog"
          aria-label={role}
          style={{
            position: 'fixed',
            top: pos.top,
            left: align === 'right' ? 'auto' : pos.left,
            right: align === 'right' ? pos.right : 'auto',
            minWidth: pos.width,
            maxHeight: pos.maxHeight,
            overflowY: 'auto',
          }}
        >
          <div className="cal-head">
            <button type="button" className="cal-nav" data-testid="cal-prev" disabled={atMin} aria-label="Previous month" onClick={() => setView((v) => addMonths(v, -1))}>
              <ChevronLeft size={17} />
            </button>
            <span className="cal-title">{format(view, 'MMMM yyyy')}</span>
            <button type="button" className="cal-nav" data-testid="cal-next" aria-label="Next month" onClick={() => setView((v) => addMonths(v, 1))}>
              <ChevronRight size={17} />
            </button>
          </div>

          <div className="cal-grid">
            {DOW.map((d) => <div key={d} className="cal-dow">{d}</div>)}
            {cells.map((d, i) =>
              d ? (
                <button key={ISO(d)} type="button" className={dayClass(d)} data-testid={`day-${ISO(d)}`} disabled={minDate ? isBefore(d, minDate) : false} onClick={() => pick(d)}>
                  {d.getDate()}
                </button>
              ) : (
                <span key={`empty-${i}`} className="cal-day empty" />
              )
            )}
          </div>

          <div className="cal-foot">
            {nights > 0 ? (
              <span><b>{nights} night{nights !== 1 ? 's' : ''}</b> selected</span>
            ) : (
              <span>{role === 'check-in' ? 'Select your check-in date' : 'Select your check-out date'}</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
