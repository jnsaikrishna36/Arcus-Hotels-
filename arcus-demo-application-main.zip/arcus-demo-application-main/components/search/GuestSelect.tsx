'use client';

import { useEffect, useRef, useState } from 'react';
import { Users, ChevronDown, Minus, Plus } from 'lucide-react';

export interface GuestSelectProps {
  value: number;
  onChange: (value: number) => void;
  testId?: string;
  align?: 'left' | 'right';
}

interface RowDef {
  key: 'adults' | 'children' | 'rooms';
  name: string;
  desc: string;
  min: number;
  max: number;
}

const ROWS: RowDef[] = [
  { key: 'adults', name: 'Adults', desc: 'Ages 13 or above', min: 1, max: 16 },
  { key: 'children', name: 'Children', desc: 'Ages 0 – 12', min: 0, max: 10 },
  { key: 'rooms', name: 'Rooms', desc: 'Number of rooms', min: 1, max: 8 },
];

export function GuestSelect({ value, onChange, testId = 'search-guests', align = 'right' }: GuestSelectProps) {
  const ref = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const popRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [counts, setCounts] = useState({ adults: Math.max(1, value || 2), children: 0, rooms: 1 });
  const [pos, setPos] = useState({ top: 0, left: 0, right: 0, width: 0, maxHeight: 320 });

  useEffect(() => {
    if (!open) return;

    if (triggerRef.current) {
      const r = triggerRef.current.getBoundingClientRect();
      const availH = window.innerHeight - r.bottom - 8 - 16;
      setPos({ top: r.bottom + 8, left: r.left, right: window.innerWidth - r.right, width: r.width, maxHeight: Math.max(120, Math.min(320, availH)) });
    }

    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    const onScroll = (e: Event) => {
      if (popRef.current && popRef.current.contains(e.target as Node)) return;
      setOpen(false);
    };

    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    window.addEventListener('scroll', onScroll, { passive: true, capture: true });
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('scroll', onScroll, true);
    };
  }, [open]);

  const step = (key: RowDef['key'], dir: 1 | -1) => {
    const row = ROWS.find((r) => r.key === key)!;
    const next = Math.min(row.max, Math.max(row.min, counts[key] + dir));
    const updated = { ...counts, [key]: next };
    setCounts(updated);
    onChange(updated.adults + updated.children);
  };

  const totalGuests = counts.adults + counts.children;
  const summary = `${totalGuests} guest${totalGuests !== 1 ? 's' : ''} · ${counts.rooms} room${counts.rooms !== 1 ? 's' : ''}`;

  return (
    <div className="sf" ref={ref} data-open={open}>
      <button
        ref={triggerRef}
        type="button"
        className="sf-trigger"
        data-testid={testId}
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        onKeyDown={(e) => {
          if (!open && ['Enter', ' ', 'ArrowDown'].includes(e.key)) { e.preventDefault(); setOpen(true); }
        }}
      >
        <span className="sf-trigger-label">
          <Users size={15} className="sf-leading-icon" />
          <span className="sf-option-label">{summary}</span>
        </span>
        <ChevronDown size={16} className="sf-chevron" />
      </button>

      {open && (
        <div
          ref={popRef}
          className={`sf-pop gs${align === 'right' ? ' sf-pop-right' : ''}`}
          role="dialog"
          aria-label="Guests"
          style={{
            position: 'fixed',
            top: pos.top,
            left: align === 'right' ? 'auto' : pos.left,
            right: align === 'right' ? pos.right : 'auto',
            minWidth: pos.width,
            maxHeight: pos.maxHeight,
            overflowY: 'auto',
          }}
        >
          {ROWS.map((r) => (
            <div key={r.key} className="gs-row">
              <div>
                <div className="gs-name">{r.name}</div>
                <div className="gs-desc">{r.desc}</div>
              </div>
              <div className="gs-ctrl">
                <button type="button" className="gs-btn" data-testid={`guests-${r.key}-dec`} aria-label={`Decrease ${r.name}`} disabled={counts[r.key] <= r.min} onClick={() => step(r.key, -1)}>
                  <Minus size={16} />
                </button>
                <span className="gs-val" data-testid={`guests-${r.key}-value`}>{counts[r.key]}</span>
                <button type="button" className="gs-btn" data-testid={`guests-${r.key}-inc`} aria-label={`Increase ${r.name}`} disabled={counts[r.key] >= r.max} onClick={() => step(r.key, 1)}>
                  <Plus size={16} />
                </button>
              </div>
            </div>
          ))}
          <div className="gs-foot">
            <button type="button" className="gs-done" data-testid="guests-done" onClick={() => setOpen(false)}>Done</button>
          </div>
        </div>
      )}
    </div>
  );
}
