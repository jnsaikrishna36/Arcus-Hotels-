'use client';

import { useEffect, useRef, useState } from 'react';
import { ChevronDown, MapPin, Globe, Check, Search } from 'lucide-react';

export interface CityGroup { group: string; tag: string; cities: string[] }

export interface CitySelectProps {
  value: string;
  onChange: (value: string) => void;
  groupedOptions: CityGroup[];
  testId?: string;
  align?: 'left' | 'right';
}

export function CitySelect({
  value,
  onChange,
  groupedOptions,
  testId = 'search-city',
  align = 'left',
}: CitySelectProps) {
  const ref = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const popRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [region, setRegion] = useState<'all' | string>('all');
  const [pos, setPos] = useState({ top: 0, left: 0, right: 0 });

  const label = value || 'All Cities';

  const visibleGroups = groupedOptions
    .filter(g => region === 'all' || g.tag === region)
    .map(g => ({ ...g, cities: g.cities.filter(c => c.toLowerCase().includes(query.toLowerCase())) }))
    .filter(g => g.cities.length > 0);

  const showHeaders = region === 'all';

  useEffect(() => {
    if (!open) { setQuery(''); return; }

    if (triggerRef.current) {
      const r = triggerRef.current.getBoundingClientRect();
      setPos({ top: r.bottom + 8, left: r.left, right: window.innerWidth - r.right });
    }
    setTimeout(() => inputRef.current?.focus(), 30);

    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    const onScroll = (e: Event) => {
      if (popRef.current && popRef.current.contains(e.target as Node)) return;
      setOpen(false);
    };

    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    window.addEventListener('scroll', onScroll, { passive: true, capture: true });
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('scroll', onScroll, true);
    };
  }, [open]);

  const choose = (v: string) => { onChange(v); setOpen(false); };
  const sanitize = (v: string) => (v || 'all').toLowerCase().replace(/\s+/g, '-');

  return (
    <div className="dd" ref={ref} data-open={open}>
      <button
        ref={triggerRef}
        type="button"
        className="dd-trigger"
        data-testid={testId}
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen(o => !o)}
      >
        <span className="dd-trigger-label">
          <MapPin size={15} className="dd-trigger-pin" />
          <span className={value ? '' : 'dd-placeholder'}>{label}</span>
        </span>
        <ChevronDown size={16} className="dd-chevron" />
      </button>

      {open && (
        <div
          ref={popRef}
          className="dd-pop ddC-pop"
          role="listbox"
          aria-label="Select destination"
          style={{
            position: 'fixed',
            top: pos.top,
            left: align === 'right' ? 'auto' : pos.left,
            right: align === 'right' ? pos.right : 'auto',
          }}
        >
          {/* Search input */}
          <div className="ddC-search">
            <Search size={15} className="ddC-search-icon" />
            <input
              ref={inputRef}
              className="ddC-input"
              placeholder="Search cities"
              value={query}
              onChange={e => setQuery(e.target.value)}
            />
          </div>

          {/* Region segment */}
          <div className="ddC-seg">
            {(['all', ...groupedOptions.map(g => g.tag)] as string[]).map((key, i) => {
              const lbl = key === 'all' ? 'All' : groupedOptions.find(g => g.tag === key)?.group ?? key;
              return (
                <button
                  key={key}
                  type="button"
                  className="ddC-seg-btn"
                  data-active={region === key}
                  onClick={() => setRegion(key)}
                >
                  {lbl}
                </button>
              );
            })}
          </div>

          {/* City list */}
          <div className="ddC-scroll">
            {/* All Cities row */}
            {(region === 'all' || query === '') && (
              <button
                type="button"
                className="ddC-row"
                role="option"
                aria-selected={value === ''}
                data-selected={value === ''}
                data-testid="city-option-all"
                onClick={() => choose('')}
              >
                <Globe size={16} className="ddC-row-icon-globe" />
                <span className="ddC-row-label">All Cities</span>
                {value === '' && <Check size={16} className="dd-check" />}
              </button>
            )}

            {visibleGroups.map(g => (
              <div key={g.group}>
                {showHeaders && (
                  <div className="ddC-head">
                    <span className="dd-chip">{g.tag}</span>
                    <span>{g.group}</span>
                  </div>
                )}
                {g.cities.map(c => (
                  <button
                    key={c}
                    type="button"
                    className="ddC-row"
                    role="option"
                    aria-selected={value === c}
                    data-selected={value === c}
                    data-testid={`city-option-${sanitize(c)}`}
                    onClick={() => choose(c)}
                  >
                    <MapPin size={15} className="ddC-row-icon" />
                    <span className="ddC-row-label">{c}</span>
                    {value === c && <Check size={16} className="dd-check" />}
                  </button>
                ))}
              </div>
            ))}

            {visibleGroups.length === 0 && query && (
              <div className="ddC-empty">No cities match &ldquo;{query}&rdquo;.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
