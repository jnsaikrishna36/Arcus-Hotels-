import { PlaneTakeoff, PlaneLanding, TrainFront, CarTaxiFront, Luggage } from 'lucide-react';

function HotAirBalloon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 2C7.5 2 4 5.5 4 9.5C4 14 7.5 17.5 11 18.5H13C16.5 17.5 20 14 20 9.5C20 5.5 16.5 2 12 2Z" />
      <line x1="5" y1="8" x2="19" y2="8" />
      <line x1="4.5" y1="12" x2="19.5" y2="12" />
      <path d="M9.5 18.5L9 21.5" />
      <path d="M14.5 18.5L15 21.5" />
      <rect x="9" y="21" width="6" height="2.5" rx="0.5" />
    </svg>
  );
}

const ITEMS: Array<{
  render: (size: number) => React.ReactElement;
  size: number;
  pos: React.CSSProperties;
  rotate: number;
  opacity: number;
}> = [
  { render: s => <PlaneTakeoff size={s} strokeWidth={1.2} aria-hidden />, size: 72, pos: { top: '9%', right: '6%' }, rotate: 20, opacity: 0.10 },
  { render: s => <TrainFront size={s} strokeWidth={1.2} aria-hidden />, size: 56, pos: { top: '65%', right: '8%' }, rotate: -8, opacity: 0.09 },
  { render: s => <CarTaxiFront size={s} strokeWidth={1.2} aria-hidden />, size: 50, pos: { bottom: '6%', left: '8%' }, rotate: 5, opacity: 0.09 },
  { render: s => <Luggage size={s} strokeWidth={1.2} aria-hidden />, size: 44, pos: { top: '26%', left: '5%' }, rotate: -18, opacity: 0.10 },
  { render: s => <HotAirBalloon size={s} />, size: 62, pos: { top: '40%', right: '4%' }, rotate: 6, opacity: 0.09 },
  { render: s => <PlaneLanding size={s} strokeWidth={1.2} aria-hidden />, size: 38, pos: { top: '52%', left: '3%' }, rotate: -25, opacity: 0.07 },
];

export function TravelDecorations() {
  return (
    <>
      {ITEMS.map((item, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            ...item.pos,
            transform: `rotate(${item.rotate}deg)`,
            opacity: item.opacity,
            color: 'white',
            pointerEvents: 'none',
            zIndex: 0,
            lineHeight: 0,
          }}
        >
          {item.render(item.size)}
        </div>
      ))}
    </>
  );
}
