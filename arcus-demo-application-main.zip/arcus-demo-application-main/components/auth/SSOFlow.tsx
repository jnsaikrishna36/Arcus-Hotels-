'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/lib/stores/auth';
import { api } from '@/lib/api';
import { toast } from '@/components/ui/Toaster';
import { SSOProvider } from '@/types';
import { ArrowLeft, ChevronRight, Plus } from 'lucide-react';

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen = 'account_chooser' | 'email_entry' | 'verifying' | 'completing';

export interface SSOFlowProps {
  provider: SSOProvider;
  onClose: () => void;
  callbackUrl?: string;
}

interface DemoAccount {
  id: string;
  name: string;
  firstName: string;
  email: string;
  initials: string;
  avatarBg: string;
}

interface ProviderTheme {
  name: string;
  cardBg: string;
  cardBorder: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  inputBg: string;
  inputBorder: string;
  inputBorderFocus: string;
  rowHoverBg: string;
  btnPrimaryBg: string;
  btnPrimaryText: string;
  accentColor: string;
  dividerColor: string;
  footerText: string;
  cardShadow: string;
  borderRadius: number;
  fontFamily: string;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const DEMO_ACCOUNTS: DemoAccount[] = [
  {
    id: 'user-1',
    name: 'Alex Johnson',
    firstName: 'Alex',
    email: 'alex@demo.com',
    initials: 'AJ',
    avatarBg: '#1a73e8',
  },
];

const THEMES: Record<SSOProvider, ProviderTheme> = {
  google: {
    name: 'Google',
    cardBg: '#ffffff',
    cardBorder: '#dadce0',
    textPrimary: '#202124',
    textSecondary: '#3c4043',
    textMuted: '#5f6368',
    inputBg: '#ffffff',
    inputBorder: '#dadce0',
    inputBorderFocus: '#1a73e8',
    rowHoverBg: '#f8f9fa',
    btnPrimaryBg: '#1a73e8',
    btnPrimaryText: '#ffffff',
    accentColor: '#1a73e8',
    dividerColor: '#e8eaed',
    footerText: '#5f6368',
    cardShadow: '0 2px 6px 2px rgba(60,64,67,.15),0 1px 2px 0 rgba(60,64,67,.3)',
    borderRadius: 8,
    fontFamily: "'Google Sans',Roboto,Arial,sans-serif",
  },
  microsoft: {
    name: 'Microsoft',
    cardBg: '#ffffff',
    cardBorder: '#8a8a8a',
    textPrimary: '#1b1b1b',
    textSecondary: '#333333',
    textMuted: '#767676',
    inputBg: '#ffffff',
    inputBorder: '#666666',
    inputBorderFocus: '#0067b8',
    rowHoverBg: '#f3f2f1',
    btnPrimaryBg: '#0067b8',
    btnPrimaryText: '#ffffff',
    accentColor: '#0067b8',
    dividerColor: '#e0e0e0',
    footerText: '#767676',
    cardShadow: '0 2px 6px rgba(0,0,0,.2)',
    borderRadius: 2,
    fontFamily: "'Segoe UI',system-ui,-apple-system,sans-serif",
  },
  github: {
    name: 'GitHub',
    cardBg: '#0d1117',
    cardBorder: '#30363d',
    textPrimary: '#c9d1d9',
    textSecondary: '#c9d1d9',
    textMuted: '#8b949e',
    inputBg: '#010409',
    inputBorder: '#30363d',
    inputBorderFocus: '#58a6ff',
    rowHoverBg: '#161b22',
    btnPrimaryBg: '#238636',
    btnPrimaryText: '#ffffff',
    accentColor: '#58a6ff',
    dividerColor: '#30363d',
    footerText: '#8b949e',
    cardShadow: '0 0 0 1px #30363d',
    borderRadius: 6,
    fontFamily: "-apple-system,BlinkMacSystemFont,'Segoe UI',monospace",
  },
};

// ─── Logo components ──────────────────────────────────────────────────────────

function GoogleLogo() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

function MicrosoftLogo() {
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg">
      <rect x="0" y="0" width="10.5" height="10.5" fill="#F25022"/>
      <rect x="11.5" y="0" width="10.5" height="10.5" fill="#7FBA00"/>
      <rect x="0" y="11.5" width="10.5" height="10.5" fill="#00A4EF"/>
      <rect x="11.5" y="11.5" width="10.5" height="10.5" fill="#FFB900"/>
    </svg>
  );
}

function GitHubLogo({ color }: { color: string }) {
  return (
    <svg width="26" height="26" viewBox="0 0 24 24" fill={color} xmlns="http://www.w3.org/2000/svg">
      <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
    </svg>
  );
}

// ─── Micro-components ─────────────────────────────────────────────────────────

function Avatar({ initials, bg, size = 40 }: { initials: string; bg: string; size?: number }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', background: bg,
      color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: size * 0.38, fontWeight: 600, flexShrink: 0, letterSpacing: '0.5px',
      userSelect: 'none',
    }}>
      {initials}
    </div>
  );
}

function Spinner({ color, size = 32 }: { color: string; size?: number }) {
  return (
    <div style={{
      width: size, height: size,
      border: `3px solid ${color}33`,
      borderTopColor: color,
      borderRadius: '50%',
      animation: 'sso-spin 0.75s linear infinite',
    }} />
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function SSOFlow({ provider, onClose, callbackUrl }: SSOFlowProps) {
  const router = useRouter();
  const { setAuth } = useAuthStore();
  const t = THEMES[provider];

  const [screen, setScreen] = useState<Screen>('account_chooser');
  const [cardOpen, setCardOpen] = useState(false);
  const [screenIn, setScreenIn] = useState(true);
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [completingUser, setCompletingUser] = useState<{ firstName: string } | null>(null);
  const [rowHover, setRowHover] = useState<string | null>(null);

  useEffect(() => {
    const id = setTimeout(() => setCardOpen(true), 10);
    return () => clearTimeout(id);
  }, []);

  // ── Screen transition ──────────────────────────────────────────────────────

  const goTo = (next: Screen) => {
    setScreenIn(false);
    setTimeout(() => { setScreen(next); setScreenIn(true); }, 200);
  };

  const closeModal = () => {
    setCardOpen(false);
    setTimeout(onClose, 250);
  };

  // ── Auth handlers ──────────────────────────────────────────────────────────

  const authenticate = async (payload: { provider: string; email?: string; code?: string }) => {
    try {
      const res = await api.post<any>('/api/auth/sso/callback', payload);
      setCompletingUser(res.data.user);
      goTo('completing');
      setTimeout(() => {
        setAuth(res.data.user, res.data.token);
        toast.success(`Signed in with ${t.name}`, `Welcome, ${res.data.user.firstName}!`);
        const redirectTo = callbackUrl && callbackUrl.startsWith('/') ? callbackUrl : (res.data.user.role === 'admin' ? '/admin/dashboard' : '/dashboard');
        router.replace(redirectTo);
      }, 1400);
    } catch (err: any) {
      toast.error('Sign-in failed', err.message);
      goTo('account_chooser');
    }
  };

  const handleSelectAccount = (account: DemoAccount) => {
    goTo('verifying');
    authenticate({ provider, email: account.email });
  };

  const handleEmailSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const trimmed = email.trim();
    if (!trimmed) { setEmailError('Enter your email or phone number'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) { setEmailError('Enter a valid email address'); return; }
    setEmailError('');
    goTo('verifying');
    authenticate({ provider, email: trimmed });
  };

  // ── Logo ───────────────────────────────────────────────────────────────────

  const ProviderLogo = () => {
    if (provider === 'google') return <GoogleLogo />;
    if (provider === 'microsoft') return <MicrosoftLogo />;
    return <GitHubLogo color={t.textPrimary} />;
  };

  // ── Screen: account chooser ────────────────────────────────────────────────

  const AccountChooserScreen = () => (
    <div data-testid="sso-screen-chooser">
      <div style={{ padding: '20px 24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <ProviderLogo />
        <button data-testid="sso-close" onClick={closeModal} style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, fontSize: 22, lineHeight: 1, padding: 4, borderRadius: 4 }}>×</button>
      </div>

      <div style={{ padding: '14px 24px 0' }}>
        <h2 style={{ fontSize: 22, fontWeight: provider === 'microsoft' ? 300 : 500, color: t.textPrimary, margin: '0 0 4px', fontFamily: t.fontFamily, letterSpacing: provider === 'github' ? '-0.5px' : 'normal' }}>
          {provider === 'github' ? 'Authorize Arcus Go' : 'Choose an account'}
        </h2>
        <p style={{ fontSize: 14, color: t.textMuted, margin: '0 0 16px', fontFamily: t.fontFamily }}>
          {provider === 'github' ? 'to continue to GitHub' : 'to continue to Arcus Go'}
        </p>
      </div>

      <div style={{ padding: '0 12px' }}>
        {DEMO_ACCOUNTS.map(acct => (
          <button
            key={acct.id}
            data-testid={`sso-account-${acct.id}`}
            onClick={() => handleSelectAccount(acct)}
            onMouseEnter={() => setRowHover(acct.id)}
            onMouseLeave={() => setRowHover(null)}
            style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 14,
              padding: '10px 12px', borderRadius: t.borderRadius,
              background: rowHover === acct.id ? t.rowHoverBg : 'transparent',
              border: '1px solid transparent',
              cursor: 'pointer', textAlign: 'left', transition: 'background 0.12s',
            }}
          >
            <Avatar initials={acct.initials} bg={acct.avatarBg} size={44} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 15, fontWeight: 500, color: t.textPrimary, marginBottom: 1, fontFamily: t.fontFamily }}>{acct.name}</div>
              <div style={{ fontSize: 13, color: t.textMuted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontFamily: t.fontFamily }}>{acct.email}</div>
            </div>
            <ChevronRight size={18} color={t.textMuted} strokeWidth={1.5} />
          </button>
        ))}

        <button
          data-testid="sso-use-another"
          onClick={() => goTo('email_entry')}
          onMouseEnter={() => setRowHover('another')}
          onMouseLeave={() => setRowHover(null)}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 14,
            padding: '10px 12px', borderRadius: t.borderRadius,
            background: rowHover === 'another' ? t.rowHoverBg : 'transparent',
            border: '1px solid transparent',
            cursor: 'pointer', textAlign: 'left', transition: 'background 0.12s',
          }}
        >
          <div style={{
            width: 44, height: 44, borderRadius: '50%',
            border: `1px solid ${t.inputBorder}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>
            <Plus size={20} color={t.textSecondary} strokeWidth={1.5} />
          </div>
          <div style={{ fontSize: 15, color: t.textSecondary, fontFamily: t.fontFamily }}>Use another account</div>
        </button>
      </div>

      <div style={{ height: 1, background: t.dividerColor, margin: '16px 0 0' }} />
      <div style={{ padding: '10px 24px 16px', display: 'flex', gap: 20, justifyContent: 'center' }}>
        {['Privacy Policy', 'Terms of Service'].map(l => (
          <span key={l} style={{ fontSize: 12, color: t.footerText, cursor: 'pointer', fontFamily: t.fontFamily }}>{l}</span>
        ))}
      </div>
    </div>
  );

  // ── Screen: email entry ────────────────────────────────────────────────────

  const EmailEntryScreen = () => (
    <div data-testid="sso-screen-email">
      <div style={{ padding: '20px 24px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button data-testid="sso-back" onClick={() => goTo('account_chooser')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, display: 'flex', alignItems: 'center', padding: 4, borderRadius: 4 }}>
            <ArrowLeft size={18} strokeWidth={1.5} />
          </button>
          <ProviderLogo />
        </div>
        <button data-testid="sso-close" onClick={closeModal} style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, fontSize: 22, lineHeight: 1, padding: 4 }}>×</button>
      </div>

      <div style={{ padding: '16px 24px 24px' }}>
        <h2 style={{ fontSize: 22, fontWeight: provider === 'microsoft' ? 300 : 500, color: t.textPrimary, margin: '0 0 4px', fontFamily: t.fontFamily }}>Sign in</h2>
        <p style={{ fontSize: 14, color: t.textMuted, margin: '0 0 24px', fontFamily: t.fontFamily }}>
          {provider === 'github' ? 'with your GitHub account' : `with your ${t.name} Account`}
        </p>

        <form onSubmit={handleEmailSubmit}>
          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 500, color: t.textSecondary, marginBottom: 6, fontFamily: t.fontFamily }}>
              {provider === 'github' ? 'Username or email address' : 'Email or phone'}
            </label>
            <input
              data-testid="sso-email-input"
              type="email"
              value={email}
              autoFocus
              onChange={e => { setEmail(e.target.value); if (emailError) setEmailError(''); }}
              onKeyDown={e => { if (e.key === 'Enter') handleEmailSubmit(); }}
              placeholder={provider === 'github' ? 'you@example.com' : ''}
              style={{
                width: '100%', padding: '10px 14px', fontSize: 15,
                background: t.inputBg, color: t.textPrimary,
                border: `1px solid ${emailError ? '#d93025' : t.inputBorder}`,
                borderRadius: t.borderRadius,
                outline: 'none', boxSizing: 'border-box',
                fontFamily: t.fontFamily,
                transition: 'border-color 0.15s',
              }}
              onFocus={e => { (e.target as HTMLInputElement).style.borderColor = t.inputBorderFocus; }}
              onBlur={e => { (e.target as HTMLInputElement).style.borderColor = emailError ? '#d93025' : t.inputBorder; }}
            />
            {emailError && <p data-testid="sso-email-error" style={{ fontSize: 12, color: '#d93025', margin: '5px 0 0', fontFamily: t.fontFamily }}>{emailError}</p>}
          </div>

          <p style={{ fontSize: 13, color: t.textMuted, margin: '0 0 24px', lineHeight: 1.6, fontFamily: t.fontFamily }}>
            {provider === 'github'
              ? 'New to GitHub? Create an account to get started.'
              : 'Not your computer? Use Guest mode to sign in privately.'}
          </p>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <button
              type="button"
              onClick={() => goTo('account_chooser')}
              style={{
                background: 'none', border: `1px solid transparent`,
                color: t.accentColor, padding: '9px 18px', borderRadius: t.borderRadius,
                fontSize: 14, fontWeight: 500, cursor: 'pointer', fontFamily: t.fontFamily,
              }}
            >
              Back
            </button>
            <button
              data-testid="sso-email-next"
              type="submit"
              style={{
                background: t.btnPrimaryBg, color: t.btnPrimaryText,
                border: 'none', padding: '9px 22px', borderRadius: t.borderRadius,
                fontSize: 14, fontWeight: 500, cursor: 'pointer', fontFamily: t.fontFamily,
              }}
            >
              Next
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  // ── Screen: verifying ──────────────────────────────────────────────────────

  const VerifyingScreen = () => (
    <div data-testid="sso-screen-verifying" style={{ padding: '48px 24px 40px', textAlign: 'center' }}>
      <ProviderLogo />
      <div style={{ display: 'flex', justifyContent: 'center', margin: '28px 0 20px' }}>
        <Spinner color={t.accentColor} size={36} />
      </div>
      <p style={{ fontSize: 16, fontWeight: 500, color: t.textPrimary, margin: '0 0 6px', fontFamily: t.fontFamily }}>
        {provider === 'github' ? 'Verifying with GitHub' : `Checking your ${t.name} account`}
      </p>
      <p style={{ fontSize: 14, color: t.textMuted, margin: 0, fontFamily: t.fontFamily }}>Please wait…</p>
    </div>
  );

  // ── Screen: completing ─────────────────────────────────────────────────────

  const CompletingScreen = () => (
    <div data-testid="sso-screen-completing" style={{ padding: '48px 24px 40px', textAlign: 'center' }}>
      <ProviderLogo />
      <div style={{
        width: 60, height: 60, borderRadius: '50%',
        background: `${t.btnPrimaryBg}22`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        margin: '28px auto 16px',
        animation: 'sso-pop 0.45s cubic-bezier(0.34,1.56,0.64,1)',
      }}>
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <path d="M4 12l5.5 5.5L20 6.5" stroke={t.btnPrimaryBg} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <p style={{ fontSize: 16, fontWeight: 500, color: t.textPrimary, margin: '0 0 6px', fontFamily: t.fontFamily }}>
        {completingUser ? `Signed in as ${completingUser.firstName}` : 'Signed in'}
      </p>
      <p style={{ fontSize: 14, color: t.textMuted, margin: 0, fontFamily: t.fontFamily }}>
        Redirecting to Arcus Go…
      </p>
    </div>
  );

  const SCREENS: Record<Screen, React.ReactNode> = {
    account_chooser: <AccountChooserScreen />,
    email_entry: <EmailEntryScreen />,
    verifying: <VerifyingScreen />,
    completing: <CompletingScreen />,
  };

  const isBlocking = screen === 'verifying' || screen === 'completing';

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <>
      {/* Backdrop */}
      <div
        data-testid="sso-backdrop"
        onClick={isBlocking ? undefined : closeModal}
        style={{
          position: 'fixed', inset: 0,
          background: 'rgba(0,0,0,0.54)',
          zIndex: 1000,
          opacity: cardOpen ? 1 : 0,
          transition: 'opacity 0.25s',
          cursor: isBlocking ? 'default' : 'pointer',
        }}
      />

      {/* Provider card */}
      <div
        data-testid={`sso-modal-${provider}`}
        role="dialog"
        aria-modal="true"
        aria-label={`Sign in with ${t.name}`}
        style={{
          position: 'fixed',
          top: '50%', left: '50%',
          transform: cardOpen
            ? 'translate(-50%, -50%) scale(1)'
            : 'translate(-50%, -48%) scale(0.95)',
          zIndex: 1001,
          width: 'calc(100% - 48px)',
          maxWidth: provider === 'microsoft' ? 440 : 400,
          background: t.cardBg,
          border: `1px solid ${t.cardBorder}`,
          borderRadius: t.borderRadius,
          boxShadow: t.cardShadow,
          opacity: cardOpen ? 1 : 0,
          transition: 'transform 0.28s cubic-bezier(0.34,1.56,0.64,1), opacity 0.25s',
          overflow: 'hidden',
        }}
      >
        {/* Screen content with transition */}
        <div style={{
          opacity: screenIn ? 1 : 0,
          transform: screenIn ? 'translateY(0)' : 'translateY(10px)',
          transition: 'opacity 0.2s ease, transform 0.2s ease',
        }}>
          {SCREENS[screen]}
        </div>
      </div>

      <style>{`
        @keyframes sso-spin { to { transform: rotate(360deg); } }
        @keyframes sso-pop {
          0%   { transform: scale(0); opacity: 0; }
          60%  { transform: scale(1.15); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </>
  );
}
