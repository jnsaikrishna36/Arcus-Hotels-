'use client';
import { useState, useEffect, useRef, useLayoutEffect, useId } from 'react';

/* ── ArcusMark ─────────────────────────────────────────────────
   Graduated dotted arc — 11 dots growing from lower-left to
   upper-right along a quadratic bezier, teal brand gradient.
   ─────────────────────────────────────────────────────────── */
export function ArcusMark({
  size = 72,
  arc = 'var(--accent)',
  arcTo = '#007e86',
  stroke = 7,
}: {
  size?: number;
  arc?: string;
  arcTo?: string;
  stroke?: number;
}) {
  const uid = useId();
  const gradId = `arcg-${uid.replace(/:/g, '')}`;

  const P0 = [12, 86], C = [38, 22], P2 = [92, 22], N = 11;
  const dots = Array.from({ length: N }, (_, i) => {
    const t = i / (N - 1), mt = 1 - t;
    const x = mt * mt * P0[0] + 2 * mt * t * C[0] + t * t * P2[0];
    const y = mt * mt * P0[1] + 2 * mt * t * C[1] + t * t * P2[1];
    let r = (1.0 + 2.4 * t) * (stroke / 6.6);
    if (i === N - 1) r *= 1.25;
    if (i === 0) r *= 1.2;
    return <circle key={i} cx={x.toFixed(2)} cy={y.toFixed(2)} r={r.toFixed(2)} fill={`url(#${gradId})`} />;
  });

  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{ display: 'block', overflow: 'visible' }} aria-hidden="true">
      <defs>
        <linearGradient id={gradId} x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor={arc} />
          <stop offset="1" stopColor={arcTo} />
        </linearGradient>
      </defs>
      {dots}
    </svg>
  );
}

/* ── AppIcon ───────────────────────────────────────────────────
   Rounded-square teal gradient box with white arc mark inside.
   ─────────────────────────────────────────────────────────── */
export function AppIcon({ size = 96 }: { size?: number }) {
  const r = Math.round(size * 0.225);
  return (
    <div style={{
      width: size, height: size,
      borderRadius: r,
      background: 'linear-gradient(140deg,#00b2bd,#007e86)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 12px 26px rgba(0,120,128,0.34)',
      position: 'relative', overflow: 'hidden', flexShrink: 0,
    }}>
      <span style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 30% 22%, rgba(255,255,255,0.5), transparent 54%)', pointerEvents: 'none' }} />
      <ArcusMark size={Math.round(size * 0.74)} arc="#ffffff" arcTo="rgba(255,255,255,0.82)" stroke={6.6} />
    </div>
  );
}

/* ── WordRotator ───────────────────────────────────────────────
   Vertical swipe animation cycling through a list of words.
   Each new word slides up in (wr-in) while the old one slides
   up out (wr-out). Width tracks the active word.
   ─────────────────────────────────────────────────────────── */
export function WordRotator({
  words,
  color = '#5fe0e6',
  interval = 2000,
}: {
  words: string[];
  color?: string;
  interval?: number;
}) {
  const [idx, setIdx] = useState(0);
  const [prev, setPrev] = useState<number | null>(null);
  const meas = useRef<(HTMLSpanElement | null)[]>([]);
  const [w, setW] = useState<number | null>(null);

  useEffect(() => {
    const t = setInterval(() => setIdx(i => { setPrev(i); return (i + 1) % words.length; }), interval);
    return () => clearInterval(t);
  }, [words.length, interval]);

  useLayoutEffect(() => {
    const el = meas.current[idx];
    if (el) setW(el.offsetWidth);
  }, [idx]);

  useEffect(() => {
    if (prev === null) return;
    const t = setTimeout(() => setPrev(null), 620);
    return () => clearTimeout(t);
  }, [prev, idx]);

  const animating = prev !== null && prev !== idx;
  const wordStyle: React.CSSProperties = { position: 'absolute', left: 0, top: 0, whiteSpace: 'nowrap', fontWeight: 800 };

  return (
    <span style={{
      position: 'relative', display: 'inline-block', overflow: 'hidden',
      height: '1.08em', verticalAlign: 'bottom',
      width: w ? `${w}px` : 'auto',
      transition: 'width .5s cubic-bezier(.2,.8,.2,1)',
      color,
    }}>
      {words.map((word, i) => (
        <span key={'m' + word} ref={el => { meas.current[i] = el; }} aria-hidden="true"
          style={{ ...wordStyle, visibility: 'hidden' }}>{word}</span>
      ))}
      {animating && (
        <span key={'out' + prev} style={{ ...wordStyle, animation: 'wr-out .56s cubic-bezier(.5,0,.15,1) both' }}>
          {words[prev]}
        </span>
      )}
      <span key={'in' + idx} style={{ ...wordStyle, animation: animating ? 'wr-in .56s cubic-bezier(.5,0,.15,1) both' : 'none' }}>
        {words[idx]}
      </span>
    </span>
  );
}
