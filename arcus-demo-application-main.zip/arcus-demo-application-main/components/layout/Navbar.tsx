'use client';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useAuthStore } from '@/lib/stores/auth';
import { User, BookOpen, LogOut, Settings, Shield, Menu, X, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { getInitials, generateColor } from '@/lib/utils';
import { toast } from '@/components/ui/Toaster';
import { AppIcon } from '@/components/brand/AppIcon';

export function Navbar() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const router = useRouter();
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    toast.success('Logged out', 'See you next time!');
    router.push('/');
  };

  const navLinks = [
    { href: '/hotels/search', label: 'Stays' },
    { href: '', label: 'Flights', disabled: true },
    { href: '', label: 'Trains', disabled: true },
    { href: '', label: 'Cabs', disabled: true },
    ...(isAuthenticated ? [{ href: '/dashboard/bookings', label: 'My Bookings' }] : []),
    ...(user?.role === 'admin' ? [{ href: '/admin/dashboard', label: 'Admin' }] : []),
  ];

  return (
    <nav
      data-testid="navbar"
      style={{
        background: 'var(--surface)',
        borderBottom: '1px solid var(--border)',
        position: 'sticky',
        top: 0,
        zIndex: 100,
        boxShadow: '0 1px 8px rgba(26,22,20,0.06)',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '64px' }}>
        {/* Logo */}
        <Link href="/" data-testid="logo" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
          <AppIcon size={38} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
            <span style={{ fontFamily: "'Bricolage Grotesque','Inter',sans-serif", fontSize: '20px', color: 'var(--ink)', fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1 }}>Arcus Go</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '10px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', lineHeight: 1 }}>
              Powered by
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/testsigma-logo.svg" alt="Testsigma" style={{ height: '12px', display: 'block', opacity: 0.7 }} />
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {navLinks.map(link =>
            (link as any).disabled ? (
              <span
                key={link.label}
                data-testid={`nav-${link.label.toLowerCase().replace(/\s/g, '-')}`}
                className="nav-link-disabled"
                style={{
                  padding: '8px 14px',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: 500,
                  color: 'var(--text-muted)',
                  userSelect: 'none',
                }}
              >
                {link.label}
              </span>
            ) : (
              <Link
                key={link.href}
                href={link.href}
                data-testid={`nav-${link.label.toLowerCase().replace(/\s/g, '-')}`}
                style={{
                  padding: '8px 14px',
                  borderRadius: '8px',
                  textDecoration: 'none',
                  fontSize: '14px',
                  fontWeight: 500,
                  color: pathname.startsWith(link.href) ? 'var(--accent)' : 'var(--text-muted)',
                  background: pathname.startsWith(link.href) ? 'var(--accent-light)' : 'transparent',
                  transition: 'all 0.15s',
                }}
                onMouseEnter={e => { if (!pathname.startsWith(link.href)) { e.currentTarget.style.background = 'var(--accent-light)'; e.currentTarget.style.color = 'var(--accent-dark)'; } }}
                onMouseLeave={e => { if (!pathname.startsWith(link.href)) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--text-muted)'; } }}
              >
                {link.label}
              </Link>
            )
          )}

          {isAuthenticated ? (
            <div style={{ position: 'relative', marginLeft: '8px' }}>
              <button
                data-testid="user-menu-trigger"
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '6px 12px',
                  borderRadius: '8px',
                  border: '1px solid var(--border)',
                  background: 'var(--surface)',
                  cursor: 'pointer',
                  transition: 'all 0.15s',
                }}
              >
                <div style={{
                  width: '30px', height: '30px', borderRadius: '50%',
                  background: generateColor(user?.id || ''),
                  color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '12px', fontWeight: 700,
                }}>
                  {getInitials(user?.firstName || '', user?.lastName || '')}
                </div>
                <span style={{ fontSize: '14px', fontWeight: 500 }}>{user?.firstName}</span>
                <ChevronDown size={14} color="var(--text-muted)" />
              </button>

              {userMenuOpen && (
                <div
                  data-testid="user-dropdown"
                  style={{
                    position: 'absolute', top: 'calc(100% + 8px)', right: 0,
                    background: 'var(--surface)', border: '1px solid var(--border)',
                    borderRadius: '10px', boxShadow: 'var(--shadow-lg)',
                    minWidth: '200px', overflow: 'hidden', zIndex: 200,
                  }}
                  onMouseLeave={() => setUserMenuOpen(false)}
                >
                  <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)' }}>
                    <div style={{ fontWeight: 600, fontSize: '14px' }}>{user?.firstName} {user?.lastName}</div>
                    <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{user?.email}</div>
                  </div>
                  {[
                    { href: '/dashboard', icon: <User size={15} />, label: 'Dashboard', testid: 'menu-dashboard' },
                    { href: '/dashboard/profile', icon: <Settings size={15} />, label: 'Profile', testid: 'menu-profile' },
                    { href: '/dashboard/bookings', icon: <BookOpen size={15} />, label: 'My Bookings', testid: 'menu-bookings' },
                    ...(user?.role === 'admin' ? [{ href: '/admin/dashboard', icon: <Shield size={15} />, label: 'Admin Portal', testid: 'menu-admin' }] : []),
                  ].map(item => (
                    <Link
                      key={item.href}
                      href={item.href}
                      data-testid={item.testid}
                      onClick={() => setUserMenuOpen(false)}
                      style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 16px', fontSize: '14px', color: 'var(--text)', textDecoration: 'none', transition: 'background 0.15s, color 0.15s' }}
                      onMouseEnter={e => { e.currentTarget.style.background = 'var(--accent-light)'; e.currentTarget.style.color = 'var(--accent-dark)'; }}
                      onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--text)'; }}
                    >
                      {item.icon}{item.label}
                    </Link>
                  ))}
                  <button
                    data-testid="logout-btn"
                    onClick={handleLogout}
                    style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 16px', fontSize: '14px', color: 'var(--error)', background: 'none', border: 'none', width: '100%', cursor: 'pointer', borderTop: '1px solid var(--border)' }}
                  >
                    <LogOut size={15} />Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div style={{ display: 'flex', gap: '8px', marginLeft: '8px' }}>
              <Link href={`/auth/login?callbackUrl=${encodeURIComponent(pathname)}`} data-testid="login-btn" style={{ padding: '8px 18px', borderRadius: '8px', border: '1px solid var(--border)', fontSize: '14px', fontWeight: 500, color: 'var(--text)', textDecoration: 'none', transition: 'all 0.15s' }}>
                Login
              </Link>
              <Link href="/auth/register" data-testid="register-btn" className="btn-primary" style={{ padding: '8px 18px', fontSize: '14px', textDecoration: 'none' }}>
                Register
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
