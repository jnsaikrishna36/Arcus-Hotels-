import { authHandlers } from './handlers/auth';
import { hotelHandlers } from './handlers/hotels';
import { paymentHandlers } from './handlers/payment';

export const handlers = [...authHandlers, ...hotelHandlers, ...paymentHandlers];
