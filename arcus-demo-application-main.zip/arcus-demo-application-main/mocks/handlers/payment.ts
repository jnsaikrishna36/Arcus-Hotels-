import { http, HttpResponse, delay } from 'msw';

export const paymentHandlers = [
  // POST /api/payments/process
  http.post('/api/payments/process', async ({ request }) => {
    await delay(2000); // Realistic payment processing delay
    const { cardNumber, amount, scenario } = await request.json() as any;

    // Test card scenarios
    // 4242424242424242 -> success
    // 4000000000000002 -> declined
    // 4000000000009995 -> insufficient funds
    // 4000000000000069 -> expired card
    const last4 = cardNumber.replace(/\s/g, '').slice(-4);

    if (cardNumber.replace(/\s/g, '') === '4000000000000002') {
      return HttpResponse.json(
        { success: false, message: 'Your card was declined. Please try a different card.', code: 'card_declined' },
        { status: 402 }
      );
    }

    if (cardNumber.replace(/\s/g, '') === '4000000000009995') {
      return HttpResponse.json(
        { success: false, message: 'Insufficient funds. Please try a different payment method.', code: 'insufficient_funds' },
        { status: 402 }
      );
    }

    if (cardNumber.replace(/\s/g, '') === '4000000000000069') {
      return HttpResponse.json(
        { success: false, message: 'Your card has expired. Please try a different card.', code: 'expired_card' },
        { status: 402 }
      );
    }

    // All other cards succeed
    return HttpResponse.json({
      success: true,
      message: 'Payment processed successfully',
      data: {
        transactionId: `TXN-${Date.now()}`,
        last4,
        amount,
        status: 'succeeded',
        timestamp: new Date().toISOString(),
      },
    });
  }),

  // POST /api/payments/paypal
  http.post('/api/payments/paypal', async ({ request }) => {
    await delay(2200); // Simulated redirect + approval round-trip

    const { email, amount } = await request.json() as any;
    const normalized = (email || '').trim().toLowerCase();

    // Test PayPal account scenarios
    // declined@paypal.com -> declined
    // nofunds@paypal.com  -> insufficient funds
    // anything else       -> success

    if (normalized === 'declined@paypal.com') {
      return HttpResponse.json(
        { success: false, message: 'PayPal declined this payment. Please try a different account.', code: 'paypal_declined' },
        { status: 402 }
      );
    }

    if (normalized === 'nofunds@paypal.com') {
      return HttpResponse.json(
        { success: false, message: 'Insufficient PayPal balance. Please try a different payment method.', code: 'insufficient_funds' },
        { status: 402 }
      );
    }

    return HttpResponse.json({
      success: true,
      message: 'PayPal payment approved',
      data: {
        transactionId: `PP-${Date.now()}`,
        payerEmail: normalized,
        amount,
        status: 'succeeded',
        timestamp: new Date().toISOString(),
      },
    });
  }),
];
