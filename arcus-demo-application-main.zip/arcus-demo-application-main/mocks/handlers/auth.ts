import { http, HttpResponse, delay } from 'msw';
import { seedUsers, ssoProfiles } from '../data/users';
import { User, SSOProvider } from '@/types';
import { v4 as uuidv4 } from 'uuid';

// In-memory user store (seeded from seedUsers)
let users = [...seedUsers];

const generateToken = (userId: string) => {
  return btoa(JSON.stringify({ userId, exp: Date.now() + 86400000, iat: Date.now() }));
};

export const authHandlers = [
  // POST /api/auth/login
  http.post('/api/auth/login', async ({ request }) => {
    await delay(600);
    const { email, password, rememberMe } = await request.json() as any;

    if (!email || !password) {
      return HttpResponse.json(
        { success: false, message: 'Email and password are required' },
        { status: 400 }
      );
    }

    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      return HttpResponse.json(
        { success: false, message: 'No account found with this email address' },
        { status: 401 }
      );
    }

    if (user.password !== password) {
      return HttpResponse.json(
        { success: false, message: 'Incorrect password. Please try again.' },
        { status: 401 }
      );
    }

    const { password: _, ...safeUser } = user;
    const token = generateToken(user.id);

    return HttpResponse.json({
      success: true,
      message: 'Login successful',
      data: { user: safeUser, token },
    });
  }),

  // POST /api/auth/register
  http.post('/api/auth/register', async ({ request }) => {
    await delay(800);
    const body = await request.json() as any;
    const { firstName, lastName, email, phone, password } = body;

    if (!firstName || !lastName || !email || !phone || !password) {
      return HttpResponse.json(
        { success: false, message: 'All fields are required' },
        { status: 400 }
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return HttpResponse.json(
        { success: false, message: 'Please enter a valid email address' },
        { status: 400 }
      );
    }

    const existing = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      return HttpResponse.json(
        { success: false, message: 'An account with this email already exists' },
        { status: 409 }
      );
    }

    const newUser: User & { password: string } = {
      id: uuidv4(),
      firstName,
      lastName,
      email,
      phone,
      password,
      role: 'user',
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);

    const { password: _, ...safeUser } = newUser;
    const token = generateToken(newUser.id);

    return HttpResponse.json({
      success: true,
      message: 'Account created successfully',
      data: { user: safeUser, token },
    }, { status: 201 });
  }),

  // POST /api/auth/forgot-password
  http.post('/api/auth/forgot-password', async ({ request }) => {
    await delay(1000);
    const { email } = await request.json() as any;

    if (!email) {
      return HttpResponse.json(
        { success: false, message: 'Email is required' },
        { status: 400 }
      );
    }

    // Always return success (mock — don't reveal if email exists)
    return HttpResponse.json({
      success: true,
      message: 'Password reset link sent to your email',
    });
  }),

  // GET /api/auth/me
  http.get('/api/auth/me', async ({ request }) => {
    await delay(300);
    const auth = request.headers.get('Authorization');
    if (!auth) {
      return HttpResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    }
    const token = auth.replace('Bearer ', '');
    try {
      const { userId } = JSON.parse(atob(token));
      const user = users.find(u => u.id === userId);
      if (!user) return HttpResponse.json({ success: false, message: 'User not found' }, { status: 404 });
      const { password: _, ...safeUser } = user;
      return HttpResponse.json({ success: true, data: safeUser });
    } catch {
      return HttpResponse.json({ success: false, message: 'Invalid token' }, { status: 401 });
    }
  }),

  // PUT /api/auth/profile
  http.put('/api/auth/profile', async ({ request }) => {
    await delay(500);
    const auth = request.headers.get('Authorization');
    if (!auth) return HttpResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });

    const token = auth.replace('Bearer ', '');
    try {
      const { userId } = JSON.parse(atob(token));
      const userIndex = users.findIndex(u => u.id === userId);
      if (userIndex === -1) return HttpResponse.json({ success: false, message: 'User not found' }, { status: 404 });

      const updates = await request.json() as any;
      users[userIndex] = { ...users[userIndex], ...updates };
      const { password: _, ...safeUser } = users[userIndex];
      return HttpResponse.json({ success: true, message: 'Profile updated', data: safeUser });
    } catch {
      return HttpResponse.json({ success: false, message: 'Invalid token' }, { status: 401 });
    }
  }),

  // GET /api/auth/sso/authorize/:provider — returns mock redirect URL
  http.get('/api/auth/sso/authorize/:provider', async ({ params }) => {
    await delay(200);
    const provider = params.provider as string;
    const valid: SSOProvider[] = ['google', 'microsoft', 'github'];
    if (!valid.includes(provider as SSOProvider)) {
      return HttpResponse.json({ success: false, message: 'Unknown SSO provider' }, { status: 400 });
    }
    const mockCode = `mock_${provider}_${uuidv4().slice(0, 8)}`;
    return HttpResponse.json({
      success: true,
      data: { redirectUrl: `/auth/sso/callback?provider=${provider}&code=${mockCode}&state=mock_state` },
    });
  }),

  // POST /api/auth/sso/callback — code-based OR email-based SSO completion
  http.post('/api/auth/sso/callback', async ({ request }) => {
    await delay(700);
    const body = await request.json() as { provider: string; code?: string; email?: string };
    const { provider, code, email } = body;

    const valid: SSOProvider[] = ['google', 'microsoft', 'github'];
    if (!valid.includes(provider as SSOProvider)) {
      return HttpResponse.json({ success: false, message: 'Unknown SSO provider' }, { status: 400 });
    }

    let targetUser: (User & { password: string }) | undefined;

    if (code) {
      // Code path: generated by the authorize endpoint
      if (!code.startsWith(`mock_${provider}_`)) {
        return HttpResponse.json({ success: false, message: 'Invalid or expired SSO code' }, { status: 401 });
      }
      const profile = ssoProfiles[provider as SSOProvider];
      targetUser = users.find(u => u.ssoProvider === provider && u.ssoId === profile.ssoId);
      if (!targetUser) {
        const newUser: User & { password: string } = {
          id: uuidv4(), ...profile, password: '',
          createdAt: new Date().toISOString(),
        };
        users.push(newUser);
        targetUser = newUser;
      }
    } else if (email) {
      // Email path: from the account chooser or "use another account" flow
      targetUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (!targetUser) {
        // Derive a display name from the email local-part
        const local = email.split('@')[0];
        const parts = local.replace(/[._+\-]+/g, ' ').split(' ').filter(Boolean);
        const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
        const newUser: User & { password: string } = {
          id: uuidv4(),
          firstName: cap(parts[0] || 'User'),
          lastName: cap(parts[1] || ''),
          email,
          phone: '',
          role: 'user',
          ssoProvider: provider as SSOProvider,
          ssoId: `${provider}-${uuidv4().slice(0, 8)}`,
          password: '',
          createdAt: new Date().toISOString(),
        };
        users.push(newUser);
        targetUser = newUser;
      }
    } else {
      return HttpResponse.json({ success: false, message: 'Either code or email is required' }, { status: 400 });
    }

    const { password: _, ...safeUser } = targetUser;
    const token = generateToken(targetUser.id);

    return HttpResponse.json({
      success: true,
      message: 'SSO login successful',
      data: { user: safeUser, token },
    });
  }),

  // GET /api/admin/users
  http.get('/api/admin/users', async ({ request }) => {
    await delay(400);
    const url = new URL(request.url);
    const search = url.searchParams.get('search') || '';
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '10');

    let filtered = users.map(({ password: _, ...u }) => u);
    if (search) {
      filtered = filtered.filter(u =>
        u.firstName.toLowerCase().includes(search.toLowerCase()) ||
        u.lastName.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase())
      );
    }

    const total = filtered.length;
    const data = filtered.slice((page - 1) * limit, page * limit);
    return HttpResponse.json({ success: true, data, total, page, limit, totalPages: Math.ceil(total / limit) });
  }),
];
