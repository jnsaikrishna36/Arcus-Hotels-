import { http, HttpResponse, delay } from 'msw';
import { hotels } from '../data/hotels';
import { Booking } from '@/types';
import { v4 as uuidv4 } from 'uuid';

// In-memory bookings store
let bookings: Booking[] = [
  {
    id: 'booking-1',
    referenceNumber: 'ARC-2024-001',
    userId: 'user-1',
    hotel: hotels[0],
    room: hotels[0].rooms[0],
    checkIn: '2024-12-15',
    checkOut: '2024-12-18',
    guests: 2,
    nights: 3,
    totalPrice: 1047,
    status: 'confirmed',
    paymentStatus: 'paid',
    paymentMethod: 'Visa ending 4242',
    createdAt: '2024-11-20T10:00:00Z',
    guestDetails: { firstName: 'Alex', lastName: 'Johnson', email: 'alex@demo.com', phone: '+1 (555) 867-5309' },
  },
  {
    id: 'booking-2',
    referenceNumber: 'ARC-2024-002',
    userId: 'user-1',
    hotel: hotels[2],
    room: hotels[2].rooms[0],
    checkIn: '2025-01-10',
    checkOut: '2025-01-14',
    guests: 2,
    nights: 4,
    totalPrice: 1036,
    status: 'completed',
    paymentStatus: 'paid',
    paymentMethod: 'Mastercard ending 5555',
    createdAt: '2024-12-01T14:00:00Z',
    guestDetails: { firstName: 'Alex', lastName: 'Johnson', email: 'alex@demo.com', phone: '+1 (555) 867-5309' },
  },
];

const generateRefNumber = () => `ARC-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`;

export const hotelHandlers = [
  // GET /api/cities
  http.get('/api/cities', async () => {
    await delay(300);
    const cityMap = new Map<string, { city: string; country: string; hotelCount: number; fromPrice: number }>();
    for (const h of hotels) {
      const existing = cityMap.get(h.city);
      if (existing) {
        existing.hotelCount += 1;
        existing.fromPrice = Math.min(existing.fromPrice, h.pricePerNight);
      } else {
        cityMap.set(h.city, { city: h.city, country: h.country, hotelCount: 1, fromPrice: h.pricePerNight });
      }
    }
    const data = Array.from(cityMap.values()).sort((a, b) => b.hotelCount - a.hotelCount);
    return HttpResponse.json({ success: true, data, total: data.length });
  }),

  // GET /api/hotels/featured
  http.get('/api/hotels/featured', async ({ request }) => {
    await delay(400);
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get('limit') || '6');
    const data = [...hotels]
      .sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount)
      .slice(0, limit);
    return HttpResponse.json({ success: true, data, total: data.length });
  }),

  // GET /api/hotels/search
  http.get('/api/hotels/search', async ({ request }) => {
    await delay(700);
    const url = new URL(request.url);
    const city = url.searchParams.get('city') || '';
    const guests = parseInt(url.searchParams.get('guests') || '1');
    const minPrice = parseInt(url.searchParams.get('minPrice') || '0');
    const maxPrice = parseInt(url.searchParams.get('maxPrice') || '999999');
    const category = url.searchParams.get('category') || '';
    const sort = url.searchParams.get('sort') || 'recommended';
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '6');

    let results = hotels.filter(h => {
      const cityMatch = !city || h.city.toLowerCase() === city.toLowerCase();
      const guestMatch = h.rooms.some(r => r.capacity >= guests && r.available);
      const priceMatch = h.pricePerNight >= minPrice && h.pricePerNight <= maxPrice;
      const categoryMatch = !category || h.category === category;
      return cityMatch && guestMatch && priceMatch && categoryMatch;
    });

    if (sort === 'price-asc') results.sort((a, b) => a.pricePerNight - b.pricePerNight);
    else if (sort === 'price-desc') results.sort((a, b) => b.pricePerNight - a.pricePerNight);
    else if (sort === 'rating') results.sort((a, b) => b.rating - a.rating);

    const total = results.length;
    const data = results.slice((page - 1) * limit, page * limit);
    return HttpResponse.json({ success: true, data, total, page, limit, totalPages: Math.ceil(total / limit) });
  }),

  // GET /api/hotels/:id
  http.get('/api/hotels/:id', async ({ params }) => {
    await delay(400);
    const hotel = hotels.find(h => h.id === params.id);
    if (!hotel) return HttpResponse.json({ success: false, message: 'Hotel not found' }, { status: 404 });
    return HttpResponse.json({ success: true, data: hotel });
  }),

  // GET /api/hotels/:id/rooms
  http.get('/api/hotels/:id/rooms', async ({ params, request }) => {
    await delay(300);
    const hotel = hotels.find(h => h.id === params.id);
    if (!hotel) return HttpResponse.json({ success: false, message: 'Hotel not found' }, { status: 404 });

    const url = new URL(request.url);
    const availableOnly = url.searchParams.get('available') === 'true';
    const guests = parseInt(url.searchParams.get('guests') || '0');

    let rooms = hotel.rooms;
    if (availableOnly) rooms = rooms.filter(r => r.available);
    if (guests > 0) rooms = rooms.filter(r => r.capacity >= guests);

    return HttpResponse.json({ success: true, data: rooms, total: rooms.length });
  }),

  // GET /api/hotels/:id/availability
  http.get('/api/hotels/:id/availability', async ({ params, request }) => {
    await delay(400);
    const hotel = hotels.find(h => h.id === params.id);
    if (!hotel) return HttpResponse.json({ success: false, message: 'Hotel not found' }, { status: 404 });

    const url = new URL(request.url);
    const checkIn = url.searchParams.get('checkIn') || '';
    const checkOut = url.searchParams.get('checkOut') || '';
    const guests = parseInt(url.searchParams.get('guests') || '1');

    if (!checkIn || !checkOut) {
      return HttpResponse.json({ success: false, message: 'checkIn and checkOut are required' }, { status: 400 });
    }

    const nights = Math.max(1, Math.round((new Date(checkOut).getTime() - new Date(checkIn).getTime()) / 86400000));
    const availableRooms = hotel.rooms
      .filter(r => r.available && r.capacity >= guests)
      .map(r => ({
        roomId: r.id,
        name: r.name,
        type: r.type,
        capacity: r.capacity,
        pricePerNight: r.pricePerNight,
        totalPrice: r.pricePerNight * nights,
      }));

    return HttpResponse.json({
      success: true,
      data: {
        hotelId: hotel.id,
        checkIn,
        checkOut,
        nights,
        guests,
        available: availableRooms.length > 0,
        rooms: availableRooms,
      },
    });
  }),

  // GET /api/bookings
  http.get('/api/bookings', async ({ request }) => {
    await delay(500);
    const auth = request.headers.get('Authorization');
    if (!auth) return HttpResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });

    const token = auth.replace('Bearer ', '');
    try {
      const { userId } = JSON.parse(atob(token));
      const url = new URL(request.url);
      const page = parseInt(url.searchParams.get('page') || '1');
      const limit = parseInt(url.searchParams.get('limit') || '10');

      const userBookings = bookings.filter(b => b.userId === userId);
      const total = userBookings.length;
      const data = userBookings.slice((page - 1) * limit, page * limit);
      return HttpResponse.json({ success: true, data, total, page, limit, totalPages: Math.ceil(total / limit) });
    } catch {
      return HttpResponse.json({ success: false, message: 'Invalid token' }, { status: 401 });
    }
  }),

  // POST /api/bookings
  http.post('/api/bookings', async ({ request }) => {
    await delay(1200);
    const auth = request.headers.get('Authorization');
    if (!auth) return HttpResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });

    const token = auth.replace('Bearer ', '');
    try {
      const { userId } = JSON.parse(atob(token));
      const body = await request.json() as any;

      const hotel = hotels.find(h => h.id === body.hotelId);
      const room = hotel?.rooms.find(r => r.id === body.roomId);
      if (!hotel || !room) {
        return HttpResponse.json({ success: false, message: 'Hotel or room not found' }, { status: 404 });
      }

      const newBooking: Booking = {
        id: uuidv4(),
        referenceNumber: generateRefNumber(),
        userId,
        hotel,
        room,
        checkIn: body.checkIn,
        checkOut: body.checkOut,
        guests: body.guests,
        nights: body.nights,
        totalPrice: body.totalPrice,
        status: 'confirmed',
        paymentStatus: 'paid',
        paymentMethod: body.paymentMethod,
        createdAt: new Date().toISOString(),
        guestDetails: body.guestDetails,
      };

      bookings.push(newBooking);
      return HttpResponse.json({ success: true, message: 'Booking confirmed', data: newBooking }, { status: 201 });
    } catch {
      return HttpResponse.json({ success: false, message: 'Booking failed' }, { status: 500 });
    }
  }),

  // GET /api/bookings/:id
  http.get('/api/bookings/:id', async ({ params, request }) => {
    await delay(300);
    const booking = bookings.find(b => b.id === params.id || b.referenceNumber === params.id);
    if (!booking) return HttpResponse.json({ success: false, message: 'Booking not found' }, { status: 404 });
    return HttpResponse.json({ success: true, data: booking });
  }),

  // PUT /api/bookings/:id/cancel
  http.put('/api/bookings/:id/cancel', async ({ params }) => {
    await delay(500);
    const idx = bookings.findIndex(b => b.id === params.id);
    if (idx === -1) return HttpResponse.json({ success: false, message: 'Booking not found' }, { status: 404 });
    bookings[idx] = { ...bookings[idx], status: 'cancelled', paymentStatus: 'refunded' };
    return HttpResponse.json({ success: true, message: 'Booking cancelled', data: bookings[idx] });
  }),

  // GET /api/admin/bookings
  http.get('/api/admin/bookings', async ({ request }) => {
    await delay(500);
    const url = new URL(request.url);
    const search = url.searchParams.get('search') || '';
    const status = url.searchParams.get('status') || '';
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '10');

    let filtered = bookings;
    if (search) filtered = filtered.filter(b =>
      b.referenceNumber.toLowerCase().includes(search.toLowerCase()) ||
      b.hotel.name.toLowerCase().includes(search.toLowerCase()) ||
      b.guestDetails.email.toLowerCase().includes(search.toLowerCase())
    );
    if (status) filtered = filtered.filter(b => b.status === status);

    const total = filtered.length;
    const data = filtered.slice((page - 1) * limit, page * limit);
    return HttpResponse.json({ success: true, data, total, page, limit, totalPages: Math.ceil(total / limit) });
  }),

  // PUT /api/admin/bookings/:id/status
  http.put('/api/admin/bookings/:id/status', async ({ params, request }) => {
    await delay(400);
    const { status } = await request.json() as any;
    const idx = bookings.findIndex(b => b.id === params.id);
    if (idx === -1) return HttpResponse.json({ success: false, message: 'Booking not found' }, { status: 404 });
    bookings[idx] = { ...bookings[idx], status };
    return HttpResponse.json({ success: true, message: 'Status updated', data: bookings[idx] });
  }),
];
