export type SSOProvider = 'google' | 'microsoft' | 'github';

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: 'user' | 'admin';
  avatar?: string;
  createdAt: string;
  ssoProvider?: SSOProvider;
  ssoId?: string;
  address?: {
    street: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  };
}

export interface Hotel {
  id: string;
  name: string;
  city: string;
  country: string;
  address: string;
  description: string;
  rating: number;
  reviewCount: number;
  pricePerNight: number;
  images: string[];
  amenities: string[];
  category: 'budget' | 'standard' | 'deluxe' | 'luxury';
  rooms: Room[];
  coordinates: { lat: number; lng: number };
}

export interface Room {
  id: string;
  hotelId: string;
  name: string;
  type: 'single' | 'double' | 'twin' | 'suite' | 'deluxe';
  capacity: number;
  pricePerNight: number;
  description: string;
  amenities: string[];
  available: boolean;
  images: string[];
}

export interface SearchParams {
  city: string;
  checkIn: string;
  checkOut: string;
  guests: number;
}

export interface BookingDraft {
  hotel: Hotel;
  room: Room;
  checkIn: string;
  checkOut: string;
  guests: number;
  nights: number;
  totalPrice: number;
}

export interface Booking {
  id: string;
  referenceNumber: string;
  userId: string;
  hotel: Hotel;
  room: Room;
  checkIn: string;
  checkOut: string;
  guests: number;
  nights: number;
  totalPrice: number;
  status: 'confirmed' | 'cancelled' | 'pending' | 'completed';
  paymentStatus: 'paid' | 'failed' | 'refunded' | 'pending';
  paymentMethod: string;
  createdAt: string;
  guestDetails: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    specialRequests?: string;
  };
}

export interface PaymentDetails {
  cardHolder: string;
  cardNumber: string;
  expiry: string;
  cvv: string;
  billingAddress: {
    street: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  };
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface ApiResponse<T> {
  data: T;
  message: string;
  success: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}
